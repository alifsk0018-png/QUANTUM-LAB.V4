"""REST endpoints for Quantum Lab user authentication and profiles."""

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy.orm import Session

from ..database.database import get_db
from ..database.models import User
from ..schemas.auth import (
    AuthResponse,
    LoginRequest,
    ProfileUpdateRequest,
    RegisterRequest,
    UserPublic,
)
from ..services import auth_service

router = APIRouter(prefix="/api/auth", tags=["Authentication"])


def get_current_user(
    authorization: str | None = Header(default=None),
    db: Session = Depends(get_db),
) -> User:
    """Resolve and require an authenticated user from the Bearer header."""
    if not authorization:
        raise HTTPException(status_code=401, detail="Authentication required.")
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token.strip():
        raise HTTPException(status_code=401, detail="Authentication required.")

    user = auth_service.get_user_by_token(db, token.strip())
    if not user:
        raise HTTPException(status_code=401, detail="Invalid or expired session token.")
    return user


@router.post("/register", response_model=AuthResponse, status_code=201)
def register(data: RegisterRequest, db: Session = Depends(get_db)):
    try:
        user, token = auth_service.register_user(db, data)
    except auth_service.EmailAlreadyExistsError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return AuthResponse(access_token=token, user=UserPublic.model_validate(user))


@router.post("/login", response_model=AuthResponse)
def login(data: LoginRequest, db: Session = Depends(get_db)):
    result = auth_service.authenticate_user(db, data.email, data.password)
    if not result:
        raise HTTPException(status_code=401, detail="Invalid email or password.")
    user, token = result
    return AuthResponse(access_token=token, user=UserPublic.model_validate(user))


@router.post("/demo", response_model=AuthResponse)
def demo_login(db: Session = Depends(get_db)):
    user = auth_service.ensure_demo_user(db)
    user.last_login_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(user)
    token = auth_service.create_access_token(user.id, user.email)
    return AuthResponse(access_token=token, user=UserPublic.model_validate(user))


@router.get("/me", response_model=UserPublic)
def get_me(current_user: User = Depends(get_current_user)):
    return UserPublic.model_validate(current_user)


@router.put("/profile", response_model=UserPublic)
def update_profile(
    data: ProfileUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    try:
        updated = auth_service.update_user_profile(db, current_user, data)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return UserPublic.model_validate(updated)


@router.post("/logout")
def logout():
    return {"logged_out": True}
