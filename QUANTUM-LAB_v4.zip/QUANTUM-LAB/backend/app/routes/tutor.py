"""REST endpoints for Q-ASSIST — AI Quantum Tutor."""

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.concurrency import run_in_threadpool
from ..schemas.tutor import (
    AIConfigRequest,
    AIConfigResponse,
    TutorRequest,
    TutorResponse,
)
from ..services.ai_service import AITutorService
from ..services import speech_service

router = APIRouter(prefix="/api", tags=["AI Tutor"])
tutor_service = AITutorService()

MAX_AUDIO_BYTES = 10 * 1024 * 1024


@router.post("/tutor/config", response_model=AIConfigResponse)
async def configure_ai(request: AIConfigRequest):
    """Save AI provider and API key to runtime environment and backend/.env."""
    try:
        updated = tutor_service.update_ai_config(
            provider=request.provider,
            api_key=request.api_key,
            model=request.model,
            api_url=request.api_url,
        )
        return AIConfigResponse(**updated)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/tutor/voice/status")
async def voice_status():
    """Report whether the offline speech-to-text engine is available."""
    return speech_service.status()


@router.post("/tutor/transcribe")
async def transcribe(audio: UploadFile = File(...), language: str = Form("en")):
    """Transcribe a recorded voice question to text (offline Whisper)."""
    data = await audio.read()
    if not data:
        raise HTTPException(status_code=400, detail="No audio received.")
    if len(data) > MAX_AUDIO_BYTES:
        raise HTTPException(status_code=413, detail="Voice clip is too long.")
    try:
        return await run_in_threadpool(speech_service.transcribe, data, language)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=422, detail=f"Could not understand the audio: {exc}"
        ) from exc


@router.post("/tutor/explain", response_model=TutorResponse)
async def explain(request: TutorRequest):
    """Generate an AI-powered (or verified educational fallback) explanation."""
    result = await tutor_service.generate_explanation(
        message=request.message,
        context_type=request.context_type,
        circuit_config=request.circuit_config,
        simulation_results=request.simulation_results,
        level=request.level,
        conversation_history=request.conversation_history,
    )
    return TutorResponse(
        explanation=result["explanation"],
        is_ai_generated=result["is_ai_generated"],
        suggestions=result.get("suggestions", []),
        level=request.level,
    )


@router.post("/tutor/chat", response_model=TutorResponse)
async def chat(request: TutorRequest):
    """Conversational follow-up endpoint for Q-ASSIST."""
    result = await tutor_service.generate_explanation(
        message=request.message,
        context_type=request.context_type or "chat",
        circuit_config=request.circuit_config,
        simulation_results=request.simulation_results,
        level=request.level,
        conversation_history=request.conversation_history,
    )
    return TutorResponse(
        explanation=result["explanation"],
        is_ai_generated=result["is_ai_generated"],
        suggestions=result.get("suggestions", []),
        level=request.level,
    )
