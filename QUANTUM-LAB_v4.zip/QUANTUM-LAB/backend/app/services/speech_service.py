"""Offline speech-to-text for Q-ASSIST voice questions.

Uses faster-whisper when available, and falls back to PyAV audio decoding +
Windows SpeechRecognitionEngine when faster-whisper / ctranslate2 is unavailable
(e.g. blocked by Windows Application Control policy).
"""

from __future__ import annotations

import io
import logging
import os
import re
import subprocess
import sys
import tempfile
import threading
import wave

logger = logging.getLogger(__name__)

WHISPER_MODEL = os.getenv("WHISPER_MODEL", "base.en").strip() or "base.en"
WHISPER_DEVICE = os.getenv("WHISPER_DEVICE", "cpu").strip() or "cpu"
WHISPER_COMPUTE_TYPE = os.getenv("WHISPER_COMPUTE_TYPE", "int8").strip() or "int8"

# Bias recognition toward the vocabulary used inside QUANTUM LAB.
QUANTUM_PROMPT = (
    "A student asks a quantum computing tutor about qubits, superposition, "
    "entanglement, the Hadamard gate, CNOT, Pauli X Y Z gates, phase, the Bloch "
    "sphere, Q-sphere, Qiskit, Aer, Bell states, GHZ, Grover's algorithm, Shor's "
    "algorithm, quantum teleportation, decoherence, measurement, kets and amplitudes."
)

_QUANTUM_FIXES: list[tuple[re.Pattern[str], object]] = [
    (re.compile(r"\bsuper\s+position\b", re.I), "superposition"),
    (re.compile(r"\bhad\s+a\s+mardi?\b|\bhadam(?:ar|er|aard|ardi?)d?\b", re.I), "Hadamard"),
    (re.compile(r"\bc\s+not\b|\bsee\s+not\b", re.I), "CNOT"),
    (
        re.compile(r"\bcue\s*bits?\b|\bq\s*bits?\b|\bcubits?\b", re.I),
        lambda m: "qubits" if m.group(0).lower().endswith("s") else "qubit",
    ),
    (re.compile(r"\bkiss\s*kit\b|\bqis\s*kit\b", re.I), "Qiskit"),
    (re.compile(r"\bbloc(?:k|h)?\s*sphere\b", re.I), "Bloch sphere"),
    (re.compile(r"\bq\s*sphere\b", re.I), "Q-sphere"),
    (re.compile(r"\bgrovers?\b", re.I), "Grover's"),
    (
        re.compile(r"\bbelle\s+states?\b", re.I),
        lambda m: "Bell states" if m.group(0).lower().endswith("s") else "Bell state",
    ),
    (re.compile(r"\bpoly\s+([xyz])\b", re.I), r"Pauli \1"),
]

try:  # Optional dependency: faster-whisper
    from faster_whisper import WhisperModel  # type: ignore

    _IMPORT_ERROR: str | None = None
except Exception as exc:  # pragma: no cover - depends on environment
    WhisperModel = None  # type: ignore
    _IMPORT_ERROR = str(exc)

try:  # Optional dependency: PyAV for decoding browser webm/ogg/mp4 clips to PCM WAV
    import av  # type: ignore

    _AV_ERROR: str | None = None
except Exception as exc:  # pragma: no cover
    av = None  # type: ignore
    _AV_ERROR = str(exc)

_model = None
_model_error: str | None = None
_lock = threading.Lock()
_loading = False


def _normalize_quantum_text(text: str) -> str:
    cleaned = re.sub(r"\s+", " ", text or "").strip()
    for pattern, repl in _QUANTUM_FIXES:
        cleaned = pattern.sub(repl, cleaned)
    return cleaned


def _sapi_ready() -> bool:
    return sys.platform == "win32" and av is not None


def is_available() -> bool:
    return (WhisperModel is not None and _model_error is None) or _sapi_ready()


def status() -> dict:
    whisper_ok = WhisperModel is not None and _model_error is None
    engine = "faster-whisper" if whisper_ok else ("windows-sapi" if _sapi_ready() else "unavailable")
    return {
        "available": is_available(),
        "engine": engine,
        "model": WHISPER_MODEL if whisper_ok else ("System.Speech" if _sapi_ready() else None),
        "loaded": _model is not None or _sapi_ready(),
        "loading": _loading,
        "error": None if is_available() else (_IMPORT_ERROR or _model_error or _AV_ERROR),
    }


def _get_model():
    global _model, _model_error, _loading
    if _model is not None:
        return _model
    if WhisperModel is None:
        raise RuntimeError(
            "faster-whisper is not available."
        )
    with _lock:
        if _model is None:
            _loading = True
            try:
                logger.info("Loading Whisper model '%s'...", WHISPER_MODEL)
                _model = WhisperModel(
                    WHISPER_MODEL, device=WHISPER_DEVICE, compute_type=WHISPER_COMPUTE_TYPE
                )
            except Exception as exc:
                _model_error = f"Could not load Whisper model '{WHISPER_MODEL}': {exc}"
                raise RuntimeError(_model_error) from exc
            finally:
                _loading = False
    return _model


def preload_in_background() -> None:
    """Warm the Whisper model at startup when faster-whisper is available."""
    if WhisperModel is None:
        return

    def _warm():
        try:
            _get_model()
            logger.info("Whisper model ready.")
        except Exception as exc:  # pragma: no cover
            logger.warning("Whisper preload failed: %s", exc)

    threading.Thread(target=_warm, name="whisper-preload", daemon=True).start()


def _decode_to_pcm16k(audio_bytes: bytes) -> tuple[bytes, float]:
    """Decode webm/ogg/mp4/wav audio bytes into 16 kHz mono 16-bit PCM."""
    if av is None:
        raise RuntimeError(f"PyAV audio decoder unavailable: {_AV_ERROR}")

    container = av.open(io.BytesIO(audio_bytes))
    try:
        if not container.streams.audio:
            raise ValueError("No audio stream found in uploaded recording.")
        resampler = av.AudioResampler(format="s16", layout="mono", rate=16000)
        chunks: list[bytes] = []
        for packet in container.demux(audio=0):
            for decoded in packet.decode():
                for frame in resampler.resample(decoded):
                    chunks.append(bytes(frame.planes[0]))
        for frame in resampler.resample(None):
            chunks.append(bytes(frame.planes[0]))
    finally:
        container.close()

    pcm = b"".join(chunks)
    duration = round(len(pcm) / (16000 * 2), 2) if pcm else 0.0
    return pcm, duration


def _transcribe_with_sapi(audio_bytes: bytes, language: str = "en") -> dict:
    pcm, duration = _decode_to_pcm16k(audio_bytes)
    if not pcm:
        return {"text": "", "language": (language or "en").split("-")[0], "duration": 0.0}

    lang_tag = language if "-" in (language or "") else "en-US"
    fd, wav_path = tempfile.mkstemp(prefix="qlab_voice_", suffix=".wav")
    os.close(fd)
    try:
        with wave.open(wav_path, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(16000)
            wf.writeframes(pcm)

        ps_script = (
            "Add-Type -AssemblyName System.Speech; "
            "$rec = $null; "
            "try { "
            "$ci = [System.Globalization.CultureInfo]::new($env:QLAB_LANG); "
            "$rec = New-Object System.Speech.Recognition.SpeechRecognitionEngine($ci) "
            "} catch { "
            "$rec = New-Object System.Speech.Recognition.SpeechRecognitionEngine "
            "}; "
            "try { "
            "$rec.LoadGrammar((New-Object System.Speech.Recognition.DictationGrammar)); "
            "$rec.SetInputToWaveFile($env:QLAB_WAV_PATH); "
            "$res = $rec.Recognize(); "
            "if ($res -and $res.Text) { [Console]::Out.Write($res.Text) } "
            "} finally { if ($rec) { $rec.Dispose() } }"
        )
        env = os.environ.copy()
        env["QLAB_WAV_PATH"] = wav_path
        env["QLAB_LANG"] = lang_tag
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_script],
            capture_output=True,
            text=True,
            timeout=25,
            env=env,
        )
        if proc.returncode != 0:
            err_msg = (proc.stderr or proc.stdout or "Windows speech recognition failed").strip()
            raise RuntimeError(err_msg)

        text = _normalize_quantum_text(proc.stdout)
        return {
            "text": text,
            "language": (language or "en").split("-")[0],
            "duration": duration,
        }
    finally:
        try:
            os.remove(wav_path)
        except OSError:
            pass


_SILENCE_HALLUCINATIONS = {
    "thank you.",
    "thank you",
    "thanks for watching.",
    "thanks for watching",
    "you",
    "you.",
    "bye.",
    "bye",
    "subtitles by the amara.org community",
}


def transcribe(audio_bytes: bytes, language: str = "en") -> dict:
    """Transcribe an uploaded audio clip (webm/ogg/wav/mp4...) to text."""
    if not audio_bytes:
        raise ValueError("Empty audio upload.")

    if WhisperModel is not None and _model_error is None:
        try:
            model = _get_model()
            segments, info = model.transcribe(
                io.BytesIO(audio_bytes),
                language=(language or "en").split("-")[0],
                beam_size=5,
                vad_filter=True,
                vad_parameters={"min_silence_duration_ms": 400},
                initial_prompt=QUANTUM_PROMPT,
                condition_on_previous_text=False,
            )
            kept_parts: list[str] = []
            for seg in segments:
                seg_text = (seg.text or "").strip()
                if not seg_text:
                    continue
                no_speech = float(getattr(seg, "no_speech_prob", 0.0) or 0.0)
                if no_speech > 0.65:
                    continue
                if no_speech > 0.35 and seg_text.lower() in _SILENCE_HALLUCINATIONS:
                    continue
                kept_parts.append(seg_text)
            text = _normalize_quantum_text(" ".join(kept_parts))
            return {
                "text": text,
                "language": info.language,
                "duration": round(float(info.duration or 0.0), 2),
            }
        except Exception as exc:
            if not _sapi_ready():
                raise
            logger.warning("faster-whisper failed (%s); falling back to Windows SAPI", exc)

    if _sapi_ready():
        return _transcribe_with_sapi(audio_bytes, language)

    raise RuntimeError(
        "Offline voice engine unavailable on this server."
    )
