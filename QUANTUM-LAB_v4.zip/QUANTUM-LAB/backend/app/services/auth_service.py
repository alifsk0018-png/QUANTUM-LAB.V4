"""Authentication and password/token utilities using Python stdlib only."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import time
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from ..database.models import User
from ..schemas.auth import ProfileUpdateRequest, RegisterRequest

AUTH_SECRET_KEY = os.getenv("AUTH_SECRET_KEY", "quantum-lab-local-dev-secret-change-in-prod")
DEMO_EMAIL = "ada@quantumlab.io"
DEMO_PASSWORD = "Quantum2026!"

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
_PBKDF2_ITERATIONS = 120_000


class EmailAlreadyExistsError(ValueError):
    """Raised when registering with an email that is already taken."""


def _b64url_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _b64url_decode(encoded: str) -> bytes:
    padding = "=" * ((4 - len(encoded) % 4) % 4)
    return base64.urlsafe_b64decode(encoded + padding)


def hash_password(password: str) -> str:
    """Hash a password with PBKDF2-HMAC-SHA256 and a random 16-byte salt."""
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        _PBKDF2_ITERATIONS,
    )
    return f"pbkdf2_sha256${_PBKDF2_ITERATIONS}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored_hash: str) -> bool:
    """Verify a password against a stored PBKDF2-HMAC-SHA256 hash."""
    try:
        scheme, iter_str, salt_hex, digest_hex = stored_hash.split("$", 3)
        if scheme != "pbkdf2_sha256":
            return False
        iterations = int(iter_str)
        salt = bytes.fromhex(salt_hex)
        expected_digest = bytes.fromhex(digest_hex)
    except (ValueError, TypeError):
        return False

    computed = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        iterations,
    )
    return hmac.compare_digest(computed, expected_digest)


def create_access_token(user_id: int, email: str, expires_seconds: int = 7 * 24 * 3600) -> str:
    """Issue a signed HS256 JWT access token."""
    now = int(time.time())
    header = _b64url_encode(
        json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(",", ":")).encode("utf-8")
    )
    payload = _b64url_encode(
        json.dumps(
            {
                "sub": str(user_id),
                "email": email,
                "iat": now,
                "exp": now + expires_seconds,
            },
            separators=(",", ":"),
        ).encode("utf-8")
    )
    signing_input = f"{header}.{payload}".encode("ascii")
    signature = hmac.new(
        AUTH_SECRET_KEY.encode("utf-8"),
        signing_input,
        hashlib.sha256,
    ).digest()
    return f"{header}.{payload}.{_b64url_encode(signature)}"


def decode_access_token(token: str) -> dict | None:
    """Verify an HS256 JWT signature and expiration, returning payload or None."""
    if not token or not isinstance(token, str):
        return None
    parts = token.strip().split(".")
    if len(parts) != 3:
        return None
    header_b64, payload_b64, sig_b64 = parts

    signing_input = f"{header_b64}.{payload_b64}".encode("ascii")
    expected_sig = hmac.new(
        AUTH_SECRET_KEY.encode("utf-8"),
        signing_input,
        hashlib.sha256,
    ).digest()
    try:
        provided_sig = _b64url_decode(sig_b64)
    except Exception:
        return None

    if not hmac.compare_digest(expected_sig, provided_sig):
        return None

    try:
        payload = json.loads(_b64url_decode(payload_b64).decode("utf-8"))
    except Exception:
        return None

    if not isinstance(payload, dict):
        return None
    exp = payload.get("exp")
    if not isinstance(exp, (int, float)) or exp <= time.time():
        return None
    return payload


def normalize_email(email: str) -> str:
    """Strip, lowercase, and validate an email address."""
    cleaned = (email or "").strip().lower()
    if not cleaned or len(cleaned) > 255 or not _EMAIL_RE.match(cleaned):
        raise ValueError("Please enter a valid email address.")
    return cleaned


def _validate_name(name: str) -> str:
    cleaned = (name or "").strip()
    if len(cleaned) < 2 or len(cleaned) > 120:
        raise ValueError("Name must be between 2 and 120 characters.")
    return cleaned


def _validate_password(password: str) -> str:
    if not isinstance(password, str) or len(password) < 6 or len(password) > 128:
        raise ValueError("Password must be between 6 and 128 characters.")
    return password


def _clean_role(role: str | None) -> str:
    cleaned = (role or "").strip()
    if not cleaned:
        return "Student"
    return cleaned[:50]


def _clean_institution(institution: str | None) -> str:
    cleaned = (institution or "").strip()
    if not cleaned:
        return "Quantum Lab Workspace"
    return cleaned[:160]


def ensure_demo_user(db: Session) -> User:
    """Create the built-in Demo Researcher account if it does not yet exist."""
    user = db.query(User).filter(User.email == DEMO_EMAIL).first()
    if user:
        return user
    user = User(
        name="Dr. Ada Vance",
        email=DEMO_EMAIL,
        password_hash=hash_password(DEMO_PASSWORD),
        role="Researcher",
        institution="Quantum Observatory Lab",
        is_demo=True,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def register_user(db: Session, data: RegisterRequest) -> tuple[User, str]:
    """Validate and register a new user, returning (user, access_token)."""
    name = _validate_name(data.name)
    email = normalize_email(data.email)
    password = _validate_password(data.password)
    role = _clean_role(data.role)
    institution = _clean_institution(data.institution)

    existing = db.query(User).filter(User.email == email).first()
    if existing:
        raise EmailAlreadyExistsError("An account with this email already exists.")

    now = datetime.now(timezone.utc)
    user = User(
        name=name,
        email=email,
        password_hash=hash_password(password),
        role=role,
        institution=institution,
        is_demo=False,
        last_login_at=now,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    token = create_access_token(user.id, user.email)
    return user, token


def authenticate_user(db: Session, email: str, password: str) -> tuple[User, str] | None:
    """Verify email/password credentials and return (user, token) or None."""
    try:
        cleaned_email = normalize_email(email)
    except ValueError:
        return None
    if not password:
        return None

    # Allow signing in with the published demo credentials even before demo endpoint is hit
    if cleaned_email == DEMO_EMAIL:
        ensure_demo_user(db)

    user = db.query(User).filter(User.email == cleaned_email).first()
    if not user or not verify_password(password, user.password_hash):
        return None

    user.last_login_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(user)

    token = create_access_token(user.id, user.email)
    return user, token


def get_user_by_token(db: Session, token: str) -> User | None:
    """Resolve a bearer JWT token to its User record, or None if invalid."""
    payload = decode_access_token(token)
    if not payload:
        return None
    sub = payload.get("sub")
    try:
        user_id = int(sub)
    except (TypeError, ValueError):
        return None
    return db.query(User).filter(User.id == user_id).first()


def update_user_profile(db: Session, user: User, data: ProfileUpdateRequest) -> User:
    """Update editable profile fields for an authenticated user."""
    if data.name is not None:
        user.name = _validate_name(data.name)
    if data.role is not None:
        user.role = _clean_role(data.role)
    if data.institution is not None:
        user.institution = _clean_institution(data.institution)

    db.commit()
    db.refresh(user)
    return user
