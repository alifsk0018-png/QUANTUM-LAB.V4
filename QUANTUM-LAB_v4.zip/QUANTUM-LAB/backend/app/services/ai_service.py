"""AI-powered quantum computing tutor service (Q-ASSIST).

Supports configurable LLM providers (Gemini, OpenAI / OpenAI-compatible, Anthropic)
via backend environment variables and falls back to a comprehensive Qiskit-backed
educational tutor engine when no API key is configured or when an API request fails.
"""

from __future__ import annotations

import json
import logging
import math
import os
import re
from pathlib import Path
from typing import Any, Optional

import httpx
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

_DEFAULT_MODELS = {
    "gemini": "gemini-2.0-flash",
    "openai": "gpt-4o-mini",
    "anthropic": "claude-3-5-sonnet-latest",
}

_DEFAULT_URLS = {
    "openai": "https://api.openai.com/v1/chat/completions",
    "anthropic": "https://api.anthropic.com/v1/messages",
}


# ------------------------------------------------------------------ #
#  Gate detail metadata for single- and multi-qubit gate queries      #
# ------------------------------------------------------------------ #

_GATE_DETAILS: dict[str, dict[str, str]] = {
    "I": {
        "action": "`I|0⟩ = |0⟩` and `I|1⟩ = |1⟩` (leaves every state unchanged).",
        "bloch": "Zero rotation; acts as a timing/barrier placeholder in multi-qubit layers.",
        "patterns": r"\b(?:identity gate|i gate)\b",
    },
    "X": {
        "action": "`X|0⟩ = |1⟩` and `X|1⟩ = |0⟩` (quantum NOT / bit-flip).",
        "bloch": "180° (`π`) rotation around the X-axis of the Bloch sphere.",
        "patterns": r"\b(?:pauli[- ]?x|not gate|bit[- ]?flip gate|x[- ]?gate)\b",
    },
    "Y": {
        "action": "`Y|0⟩ = i|1⟩` and `Y|1⟩ = −i|0⟩` (combined bit-flip and phase-flip).",
        "bloch": "180° (`π`) rotation around the Y-axis of the Bloch sphere.",
        "patterns": r"\b(?:pauli[- ]?y|y[- ]?gate)\b",
    },
    "Z": {
        "action": "`Z|0⟩ = |0⟩` and `Z|1⟩ = −|1⟩` (phase-flip by `π`).",
        "bloch": "180° (`π`) rotation around the Z-axis; swaps `|+⟩ ↔ |−⟩`.",
        "patterns": r"\b(?:pauli[- ]?z|phase[- ]?flip gate|z[- ]?gate)\b",
    },
    "H": {
        "action": "`H|0⟩ = |+⟩ = (|0⟩ + |1⟩)/√2` and `H|1⟩ = |−⟩ = (|0⟩ − |1⟩)/√2`.",
        "bloch": "180° (`π`) rotation around the diagonal `(X + Z)/√2` axis, swapping Z and X bases. Self-inverse (`H² = I`).",
        "patterns": r"\b(?:hadamard|h[- ]?gate)\b",
    },
    "S": {
        "action": "`S|0⟩ = |0⟩` and `S|1⟩ = i|1⟩` (`π/2` phase shift; `S² = Z`).",
        "bloch": "90° (`π/2`) rotation around the Z-axis; maps `|+⟩ → |+i⟩`.",
        "patterns": r"\b(?:s[- ]?gate|sqrt\(?z\)? gate|phase gate)\b",
    },
    "T": {
        "action": "`T|0⟩ = |0⟩` and `T|1⟩ = e^{iπ/4}|1⟩` (`π/4` phase shift; `T² = S`).",
        "bloch": "45° (`π/4`) rotation around the Z-axis. With `{H, CNOT}`, `T` makes the gate set universal.",
        "patterns": r"\b(?:t[- ]?gate|pi/8 gate)\b",
    },
    "RX": {
        "action": "`RX(θ) = cos(θ/2)I − i·sin(θ/2)X`. At `θ = π`, equals `−iX` (flips `|0⟩ ↔ |1⟩`).",
        "bloch": "Continuous rotation by angle `θ` around the X-axis.",
        "patterns": r"\b(?:rx|rotation[- ]?x)\b",
    },
    "RY": {
        "action": "`RY(θ)|0⟩ = cos(θ/2)|0⟩ + sin(θ/2)|1⟩` (creates any real-amplitude superposition).",
        "bloch": "Continuous rotation by angle `θ` around the Y-axis.",
        "patterns": r"\b(?:ry|rotation[- ]?y)\b",
    },
    "RZ": {
        "action": "`RZ(θ)|0⟩ = e^{−iθ/2}|0⟩` and `RZ(θ)|1⟩ = e^{+iθ/2}|1⟩` (relative phase `θ`).",
        "bloch": "Continuous rotation by angle `θ` around the Z-axis.",
        "patterns": r"\b(?:rz|rotation[- ]?z)\b",
    },
    "CX": {
        "action": "`CX|00⟩=|00⟩`, `CX|01⟩=|01⟩`, `CX|10⟩=|11⟩`, `CX|11⟩=|10⟩` (flips target iff control is `|1⟩`).",
        "bloch": "2-qubit entangling gate. Combine `H` on control + `CX` to generate a Bell pair `(|00⟩ + |11⟩)/√2`.",
        "patterns": r"\b(?:cnot|cx|controlled[- ]?(?:x|not))\b",
    },
    "CZ": {
        "action": "`CZ|11⟩ = −|11⟩` and leaves `|00⟩, |01⟩, |10⟩` unchanged (symmetric controlled phase-flip).",
        "bloch": "2-qubit entangling gate; flips the sign of `|11⟩`. Note `CZ = (I⊗H)·CX·(I⊗H)`.",
        "patterns": r"\b(?:cz|controlled[- ]?z)\b",
    },
    "SWAP": {
        "action": "`SWAP|a,b⟩ = |b,a⟩` (exchanges the quantum states of two qubits).",
        "bloch": "Decomposes into 3 alternating `CX` gates and preserves entanglement without measuring.",
        "patterns": r"\bswap\b",
    },
    "CCX": {
        "action": "`CCX|a,b,c⟩ = |a,b, c ⊕ (a∧b)⟩` (flips target only when both controls are `|1⟩`).",
        "bloch": "3-qubit Toffoli gate; universal for reversible classical logic (e.g., quantum AND/adders).",
        "patterns": r"\b(?:toffoli|ccx|controlled[- ]?controlled[- ]?(?:x|not))\b",
    },
}


# ------------------------------------------------------------------ #
#  Curated Quantum Computing Knowledge Base                           #
# ------------------------------------------------------------------ #

_KNOWLEDGE_TOPICS: list[dict[str, Any]] = [
    {
        "id": "bell_state_bloch",
        "title": "Why a Single-Qubit Bloch Sphere Cannot Show an Entangled Bell State",
        "keywords": [
            ("bloch sphere", 4), ("bell state", 4), ("entangled", 3),
            ("can't a bloch", 6), ("cannot a bloch", 6), ("show an entangled", 6),
            ("reduced density", 4), ("mixed state", 3),
        ],
        "beginner": (
            "A single-qubit **Bloch sphere** can only draw the state of **one independent qubit** (`α|0⟩ + β|1⟩`).\n\n"
            "In a Bell state such as `|Φ⁺⟩ = (|00⟩ + |11⟩)/√2`, neither qubit has its own private state — "
            "each individual qubit looks completely random (50% `0`, 50% `1`) on its own, so its Bloch vector collapses "
            "to the **dead center** of the sphere `(0, 0, 0)`.\n\n"
            "All of the quantum information lives in the **correlation between qubits** (`00` together or `11` together), "
            "which is why QUANTUM LAB provides the **Q-Sphere** and **Statevector** views for multi-qubit entangled circuits."
        ),
        "advanced": (
            "A single-qubit Bloch sphere parameterizes pure single-qubit states (surface `|r| = 1`) or single-qubit density matrices `ρ = (I + r·σ)/2` (`|r| ≤ 1`).\n\n"
            "For `|Φ⁺⟩ = (|00⟩ + |11⟩)/√2`, tracing out qubit B gives the reduced density matrix:\n"
            "`ρ_A = Tr_B(|Φ⁺⟩⟨Φ⁺|) = ½(|0⟩⟨0| + |1⟩⟨1|) = ½ I`\n\n"
            "Its purity is `Tr(ρ_A²) = 0.5` (maximally mixed) and its Bloch vector is `r = (0, 0, 0)` at the center of the sphere, losing all cross-qubit phase and correlation terms (`|00⟩⟨11|`). Use the **Q-Sphere** or full 2^N **Statevector** to inspect entangled states."
        ),
        "suggestions": [
            "What is the Q-Sphere?",
            "How does entanglement work?",
            "Explain my circuit",
        ],
    },
    {
        "id": "bloch_sphere",
        "title": "The Bloch Sphere",
        "keywords": [
            ("bloch sphere", 6), ("bloch", 4), ("north pole", 2), ("south pole", 2), ("theta", 1), ("phi", 1),
        ],
        "beginner": (
            "The **Bloch sphere** is a 3D unit sphere that visualizes any pure single-qubit state:\n"
            "`|ψ⟩ = cos(θ/2)|0⟩ + e^{iφ} sin(θ/2)|1⟩`\n\n"
            "- **North Pole (+Z):** `|0⟩`\n"
            "- **South Pole (−Z):** `|1⟩`\n"
            "- **Equator (±X, ±Y):** Equal superpositions such as `|+⟩ = (|0⟩+|1⟩)/√2`, `|−⟩ = (|0⟩−|1⟩)/√2`, and `|±i⟩`, differing only by their relative phase `φ`.\n\n"
            "Every single-qubit unitary gate (`X, Y, Z, H, S, T, RX, RY, RZ`) simply rotates the state arrow around an axis of this sphere."
        ),
        "advanced": (
            "Any normalized single-qubit state up to global phase maps to a unit vector `r = (sinθ cosφ, sinθ sinφ, cosθ)` on `S²`, where `ρ = (I + r·σ)/2`.\n\n"
            "Notice that orthogonal states `|0⟩` and `|1⟩` sit **180° apart** (opposite poles), which explains why angles on the Bloch sphere correspond to `θ/2` in state amplitudes (`RX(π)` flips `|0⟩` to `−i|1⟩`). Mixed or entangled single-qubit reduced states lie strictly inside the ball (`|r| < 1`)."
        ),
        "suggestions": [
            "Why can't a Bloch sphere show an entangled Bell state?",
            "What is the Q-Sphere?",
            "What is superposition?",
        ],
    },
    {
        "id": "q_sphere",
        "title": "The Q-Sphere Visualization",
        "keywords": [("q-sphere", 6), ("qsphere", 6), ("q sphere", 6), ("hamming weight", 3)],
        "beginner": (
            "The **Q-Sphere** visualizes an entire multi-qubit statevector at once (including entangled states that a single-qubit Bloch sphere cannot show):\n\n"
            "- **Latitude (top to bottom):** Number of `1`s in each basis bitstring (Hamming weight — `|00…0⟩` at the north pole, `|11…1⟩` at the south pole).\n"
            "- **Dot Size:** Measurement probability `|c_x|²` of that outcome.\n"
            "- **Color:** Relative phase angle `arg(c_x)` of that state's complex amplitude.\n\n"
            "For a Bell state `(|00⟩ + |11⟩)/√2`, you see two equal-sized nodes at the north (`|00⟩`) and south (`|11⟩`) poles."
        ),
        "suggestions": [
            "Why can't a Bloch sphere show an entangled Bell state?",
            "What do the statevector phases tell us?",
            "How does entanglement work?",
        ],
    },
    {
        "id": "qubit",
        "title": "Qubits vs. Classical Bits",
        "keywords": [
            ("qubit", 5), ("qubits", 5), ("qbit", 5), ("classical bit", 4), ("bits vs qubits", 5), ("difference between a bit", 5),
        ],
        "beginner": (
            "A **classical bit** is strictly `0` or `1` (like a light switch that is either OFF or ON).\n\n"
            "A **qubit** (quantum bit) has two basis states `|0⟩` and `|1⟩`, and can exist in any coherent **superposition** `|ψ⟩ = α|0⟩ + β|1⟩` where `α` and `β` are complex numbers satisfying `|α|² + |β|² = 1`.\n\n"
            "- When measured, the qubit yields `0` with probability `|α|²` or `1` with probability `|β|²`.\n"
            "- Across `N` qubits, the system holds `2^N` complex amplitudes simultaneously, enabling **interference** and **entanglement** — two capabilities classical bits do not have."
        ),
        "advanced": (
            "A qubit is a two-level quantum mechanical system whose pure states live in `ℂ²` (normalized up to global phase, i.e., `ℂℙ¹ ≅ S²`). Computational basis vectors are `|0⟩ = [1, 0]ᵀ` and `|1⟩ = [0, 1]ᵀ`.\n\n"
            "In hardware, qubits are realized via superconducting transmon junctions, trapped atomic ions, neutral-atom Rydberg arrays, photonic paths/polarizations, or semiconductor spin states. An `N`-qubit register lives in `(ℂ²)^{⊗N} ≅ ℂ^{2^N}`."
        ),
        "suggestions": [
            "What is superposition?",
            "What is the Bloch sphere?",
            "What is Dirac notation?",
        ],
    },
    {
        "id": "superposition",
        "title": "Quantum Superposition",
        "keywords": [("superposition", 6), ("plus state", 3), ("|+>", 3), ("|->", 3)],
        "beginner": (
            "**Superposition** means a quantum system exists in a coherent linear combination of basis states before measurement.\n\n"
            "A pure single-qubit state is written as `|ψ⟩ = α|0⟩ + β|1⟩`, where `α` and `β` are complex probability amplitudes with `|α|² + |β|² = 1`.\n\n"
            "**Example:** Applying a **Hadamard (`H`)** gate to `|0⟩` creates `|+⟩ = (|0⟩ + |1⟩)/√2` — giving **50%** probability for `|0⟩` and **50%** for `|1⟩` upon measurement. Unlike an already-flipped hidden coin, superposition retains a relative phase between `|0⟩` and `|1⟩` that can interfere in later gates (`H|+⟩ = |0⟩`)."
        ),
        "suggestions": [
            "Explain the Hadamard gate",
            "How does quantum interference work?",
            "How does entanglement work?",
        ],
    },
    {
        "id": "entanglement",
        "title": "Quantum Entanglement & Bell States",
        "keywords": [
            ("entanglement", 6), ("entangle", 5), ("bell state", 4), ("bell pair", 4),
            ("ghz", 4), ("epr", 3), ("non-separable", 3),
        ],
        "beginner": (
            "**Quantum Entanglement** occurs when two or more qubits become linked into a single joint quantum state that **cannot** be written as independent states `|ψ_A⟩ ⊗ |ψ_B⟩`.\n\n"
            "The standard Bell state is `|Φ⁺⟩ = (|00⟩ + |11⟩)/√2`:\n"
            "- Measuring qubit 0 alone gives `0` or `1` randomly (50%/50%).\n"
            "- Yet measuring qubit 1 **always** produces the exact same bit (`00` or `11`, never `01` or `10`).\n\n"
            "**Build it in QUANTUM LAB:** Put `H` on `q0`, then `CX` (CNOT) with control `q0` and target `q1`. To entangle 3+ qubits into a **GHZ state** `(|000⟩ + |111⟩)/√2`, add `CX(q0 → q2)`."
        ),
        "suggestions": [
            "Why can't a Bloch sphere show an entangled Bell state?",
            "How does quantum teleportation work?",
            "Explain the CNOT gate",
        ],
    },
    {
        "id": "teleportation",
        "title": "Quantum Teleportation",
        "keywords": [("teleportation", 6), ("teleport", 5), ("no-cloning", 2)],
        "beginner": (
            "**Quantum Teleportation** transfers an unknown quantum state `|ψ⟩` from Alice (`q0`) to Bob (`q2`) without physically moving the qubit itself.\n\n"
            "**How the 3-qubit protocol works:**\n"
            "1. **Share entanglement:** Create a Bell pair `(|00⟩ + |11⟩)/√2` on `(q1, q2)` using `H(q1)` + `CX(q1 → q2)`.\n"
            "2. **Bell-basis mix:** Alice applies `CX(q0 → q1)` followed by `H(q0)`, then measures `q0` and `q1` into 2 classical bits.\n"
            "3. **Classical correction:** Alice sends those 2 classical bits to Bob, who applies `X` (if `q1 = 1`) and `Z` (if `q0 = 1`) to `q2` — recovering exact `|ψ⟩` on `q2`.\n\n"
            "It obeys both the **No-Cloning Theorem** (Alice's original `|ψ⟩` collapses) and relativity (Bob must wait for the 2 classical bits)."
        ),
        "suggestions": [
            "What is the No-Cloning Theorem?",
            "How does entanglement work?",
            "What is superdense coding?",
        ],
    },
    {
        "id": "superdense_coding",
        "title": "Superdense Coding",
        "keywords": [("superdense", 6), ("dense coding", 5)],
        "beginner": (
            "**Superdense Coding** is the dual of teleportation: Alice sends **2 classical bits** to Bob by transmitting just **1 qubit**, using a pre-shared Bell pair.\n\n"
            "- Start with `|Φ⁺⟩ = (|00⟩ + |11⟩)/√2` shared between Alice and Bob.\n"
            "- To send `00`, `01`, `10`, or `11`, Alice applies `I`, `X`, `Z`, or `ZX` to her single qubit and sends it to Bob.\n"
            "- Bob applies `CX` then `H` and measures both qubits to read Alice's exact 2-bit message."
        ),
        "suggestions": [
            "How does quantum teleportation work?",
            "How does entanglement work?",
        ],
    },
    {
        "id": "interference",
        "title": "Quantum Interference",
        "keywords": [("interference", 6), ("constructive", 3), ("destructive", 3)],
        "beginner": (
            "**Quantum Interference** happens because probability amplitudes can be positive, negative, or complex — unlike classical probabilities which can only add up.\n\n"
            "- **Constructive interference:** Amplitudes with the **same** phase reinforce, increasing measurement probability.\n"
            "- **Destructive interference:** Amplitudes with **opposite** signs cancel to zero!\n\n"
            "**Classic 1-qubit experiment (`H → Z → H` on `|0⟩`):**\n"
            "1. `H|0⟩ = (|0⟩ + |1⟩)/√2`\n"
            "2. `Z` flips the phase of `|1⟩`: `(|0⟩ − |1⟩)/√2`\n"
            "3. Second `H`: the `|0⟩` paths (`+1/2` and `−1/2`) cancel completely, while `|1⟩` reinforces (`+1/2 + 1/2 = 1`), yielding **100% `|1⟩`**."
        ),
        "suggestions": [
            "What do the statevector phases tell us?",
            "How does Grover's search beat classical search?",
            "Explain the Hadamard gate",
        ],
    },
    {
        "id": "shots",
        "title": "Shots & Sampling Variance",
        "keywords": [
            ("shot", 4), ("shots", 5), ("differ slightly", 5), ("sampling variance", 5),
            ("theoretical probabilities", 5), ("512", 2), ("1024", 2),
        ],
        "beginner": (
            "Each execution (**shot**) of a quantum circuit produces **one** collapsed classical bitstring sampled randomly from the Born rule probability distribution `P(x) = |c_x|²`.\n\n"
            "Even for an exact 50%/50% superposition `H|0⟩`, running `N = 1024` shots acts like flipping a fair coin 1024 times: counts typically land around `503` and `521` instead of `512` and `512`.\n\n"
            "- The standard deviation of the estimated probability shrinks as `σ = √(p(1 − p) / N)`.\n"
            "- Increasing **shots** reduces sampling noise (`4×` shots cuts statistical error in half), while **Ideal Mode** also computes the exact theoretical `Statevector` probabilities."
        ),
        "suggestions": [
            "How does quantum measurement work?",
            "Compare ideal vs. noisy execution for this circuit",
            "What do the statevector phases tell us?",
        ],
    },
    {
        "id": "measurement",
        "title": "Quantum Measurement & the Born Rule",
        "keywords": [("measurement", 6), ("measure", 4), ("born rule", 5), ("collapse", 4), ("wavefunction", 3)],
        "beginner": (
            "**Measurement** extracts classical bit outcomes (`0` or `1` per qubit) from a quantum register.\n\n"
            "By the **Born rule**, measuring state `|ψ⟩ = ∑ c_x |x⟩` in the computational basis yields bitstring `|x⟩` with probability:\n"
            "`P(x) = |⟨x|ψ⟩|² = |c_x|²`\n\n"
            "Projective measurement is **irreversible**: the superposition collapses onto the single observed basis state `|x⟩`, erasing relative phases. That is why quantum circuits are repeated over many **shots** (e.g., 1024) to estimate outcome probabilities."
        ),
        "suggestions": [
            "Why do shot counts differ slightly from theoretical probabilities?",
            "What do the statevector phases tell us?",
            "What is superposition?",
        ],
    },
    {
        "id": "statevector_phase",
        "title": "Statevectors, Amplitudes & Quantum Phases",
        "keywords": [
            ("statevector", 6), ("state vector", 6), ("phases", 5), ("phase", 4),
            ("relative phase", 5), ("global phase", 4), ("amplitude", 4), ("amplitudes", 4),
        ],
        "beginner": (
            "The **statevector** is the complete mathematical list of `2^N` complex numbers (`c_x = a + bi = r·e^{iφ}`) describing an `N`-qubit pure state `|ψ⟩ = ∑ c_x |x⟩`.\n\n"
            "- **Magnitude `r = |c_x|`:** Determines measurement probability `P(x) = r²`.\n"
            "- **Phase angle `φ = arg(c_x)`:** Doesn't change Z-basis probabilities on its own, **but relative phases between basis states drive quantum interference!** For example, `|+⟩` (`0` phase) and `|−⟩` (`π` phase on `|1⟩`) both measure 50%/50% in the Z basis, yet `H` maps `|+⟩ → |0⟩` and `|−⟩ → |1⟩`.\n"
            "- **Global phase** (multiplying the whole state by `e^{iγ}`) has no observable effect; only **relative phase differences** matter."
        ),
        "suggestions": [
            "How does quantum interference work?",
            "What is the Q-Sphere?",
            "What is Dirac notation?",
        ],
    },
    {
        "id": "dirac_notation",
        "title": "Dirac (Bra-Ket) Notation & Hilbert Space",
        "keywords": [
            ("dirac", 6), ("bra-ket", 6), ("braket", 6), ("ket", 4), ("bra", 3),
            ("hilbert", 5), ("tensor product", 5), ("inner product", 4),
        ],
        "beginner": (
            "**Dirac notation** is the standard shorthand for quantum states and linear algebra:\n\n"
            "- **Ket `|ψ⟩`:** A column vector in `2^N`-dimensional complex Hilbert space (e.g., `|0⟩ = [1, 0]ᵀ`, `|1⟩ = [0, 1]ᵀ`).\n"
            "- **Bra `⟨φ|`:** The conjugate transpose (row vector) of `|φ⟩`.\n"
            "- **Inner product `⟨φ|ψ⟩`:** Overlap between states; `|⟨x|ψ⟩|²` is the Born-rule measurement probability.\n"
            "- **Tensor product `|a⟩ ⊗ |b⟩ = |ab⟩`:** Combines separate qubits into a joint multi-qubit state (`N` qubits span `2^N` basis states)."
        ),
        "suggestions": [
            "What is a qubit?",
            "What do the statevector phases tell us?",
            "What is superposition?",
        ],
    },
    {
        "id": "grover",
        "title": "Grover's Search Algorithm",
        "keywords": [
            ("grover", 6), ("amplitude amplification", 5), ("diffusion", 4),
            ("oracle", 3), ("unstructured search", 4), ("beat classical search", 5),
        ],
        "beginner": (
            "**Grover's Algorithm** searches an unsorted database of `N` items in **`O(√N)`** queries instead of the **`O(N)`** steps required classically (a quadratic speedup).\n\n"
            "**How it works:**\n"
            "1. **Uniform Superposition:** Apply `H` to all qubits so every item has equal amplitude `1/√N`.\n"
            "2. **Phase Oracle:** Flips the sign (`−`) of the marked target state (e.g., `CZ` marks `|11⟩`).\n"
            "3. **Grover Diffuser (Inversion about the Mean):** Reflects all amplitudes around their average (`H → X → multi-Z → X → H`), boosting the negative marked amplitude above the rest.\n\n"
            "Repeating steps 2–3 `≈ (π/4)√N` times amplifies the answer. For **2 qubits (`N = 4`)**, **1 iteration** finds `|11⟩` with **100% probability**!"
        ),
        "suggestions": [
            "How does quantum interference work?",
            "What is Shor's algorithm?",
            "Suggest an experiment",
        ],
    },
    {
        "id": "shor",
        "title": "Shor's Algorithm & Quantum Fourier Transform",
        "keywords": [
            ("shor", 6), ("factoring", 5), ("factorization", 5), ("rsa", 4),
            ("qft", 5), ("fourier", 5), ("period finding", 5), ("phase estimation", 4), ("qpe", 4),
        ],
        "beginner": (
            "**Shor's Algorithm** factors large integers in polynomial time `O((log N)³)` — exponentially faster than the best known classical algorithms — threatening classical RSA encryption once large fault-tolerant quantum computers exist.\n\n"
            "**Key ingredients:**\n"
            "1. Reduce factoring `N` to finding the **period `r`** of `a^x mod N`.\n"
            "2. Use the **Quantum Fourier Transform (QFT)** (built from `H` and controlled phase rotations) to extract period `r` from constructive interference peaks.\n\n"
            "Closely related is **Quantum Phase Estimation (QPE)**, which estimates eigenvalues of unitary operators for quantum chemistry and materials simulation."
        ),
        "suggestions": [
            "What is quantum cryptography (QKD)?",
            "How does Grover's search beat classical search?",
            "What is quantum computing?",
        ],
    },
    {
        "id": "deutsch_jozsa",
        "title": "Deutsch-Jozsa & Bernstein-Vazirani Algorithms",
        "keywords": [
            ("deutsch", 6), ("jozsa", 6), ("bernstein", 6), ("vazirani", 6), ("simon", 5),
        ],
        "beginner": (
            "These landmark algorithms demonstrate how **phase kickback** and **interference** extract global properties in **1 query**:\n\n"
            "- **Deutsch-Jozsa:** Determines whether a black-box Boolean function `f(x)` is *constant* (same output for all inputs) or *balanced* (half 0, half 1) in **1 oracle call** (versus up to `2^{n-1}+1` classically).\n"
            "- **Bernstein-Vazirani:** Recovers a hidden `n`-bit string `s` inside `f(x) = s · x mod 2` in **1 query** instead of `n` classical queries, by wrapping the oracle in `H⊗n` gates."
        ),
        "suggestions": [
            "How does Grover's search beat classical search?",
            "How does quantum interference work?",
        ],
    },
    {
        "id": "vqe_qaoa",
        "title": "Variational Quantum Algorithms (VQE & QAOA)",
        "keywords": [("vqe", 6), ("qaoa", 6), ("variational", 5), ("ansatz", 4)],
        "beginner": (
            "**VQE** (Variational Quantum Eigensolver) and **QAOA** (Quantum Approximate Optimization Algorithm) are hybrid quantum-classical algorithms designed for **NISQ** processors:\n\n"
            "1. A parameterized circuit (an **ansatz** using `RX, RY, RZ` and `CX` gates) prepares a trial state `|ψ(θ)⟩`.\n"
            "2. The quantum processor measures expectation values (e.g., molecular ground-state energy or Max-Cut cost).\n"
            "3. A classical optimizer updates parameters `θ` in a feedback loop until the cost reaches a minimum."
        ),
        "suggestions": [
            "What is quantum noise and decoherence?",
            "Explain the RY gate",
        ],
    },
    {
        "id": "noise_decoherence",
        "title": "Quantum Noise, Decoherence & NISQ Errors",
        "keywords": [
            ("noise", 5), ("noisy", 5), ("decoherence", 6), ("depolarizing", 5),
            ("nisq", 5), ("t1", 3), ("t2", 3), ("readout error", 5), ("ideal vs", 4),
        ],
        "beginner": (
            "Today's **NISQ** (Noisy Intermediate-Scale Quantum) processors suffer from environmental interactions and imperfect control pulses:\n\n"
            "- **Decoherence (`T₁` relaxation & `T₂` dephasing):** Qubits lose energy (`|1⟩ → |0⟩`) or lose phase coherence over time, so deeper circuits accumulate more errors.\n"
            "- **Depolarizing gate errors:** Imperfect pulses occasionally apply unwanted `X`, `Y`, or `Z` flips (especially on 2-qubit `CX` gates).\n"
            "- **Readout assignment errors:** Measurement hardware occasionally misreads `0` as `1` or vice versa.\n\n"
            "In QUANTUM LAB, switch to **Noisy Mode** (powered by **Qiskit Aer**) to see error leakage — such as small `|01⟩` and `|10⟩` counts appearing inside a Bell state."
        ),
        "suggestions": [
            "What is Quantum Error Correction?",
            "Compare ideal vs. noisy execution for this circuit",
            "Explain my circuit",
        ],
    },
    {
        "id": "error_correction",
        "title": "Quantum Error Correction (QEC)",
        "keywords": [
            ("error correction", 6), ("qec", 6), ("syndrome", 5), ("surface code", 5),
            ("bit-flip code", 5), ("logical qubit", 4), ("fault tolerant", 4),
        ],
        "beginner": (
            "Because the **No-Cloning Theorem** forbids copying arbitrary unknown states `α|0⟩ + β|1⟩`, classical repetition backup does not work directly.\n\n"
            "**Quantum Error Correction (QEC)** solves this by:\n"
            "1. **Encoding** one logical qubit across multiple entangled physical qubits (e.g., `|0⟩_L = |000⟩`, `|1⟩_L = |111⟩`, so `α|0⟩ + β|1⟩ ↦ α|000⟩ + β|111⟩`).\n"
            "2. **Measuring parity syndromes** on ancilla qubits (`Z₀Z₁`, `Z₁Z₂`) to detect *which* qubit flipped **without** collapsing `α` or `β`.\n"
            "3. Applying targeted recovery gates (`X` or `Z`). Combining bit-flip and phase-flip protection yields codes like Shor's 9-qubit code and **surface codes**."
        ),
        "suggestions": [
            "What is the No-Cloning Theorem?",
            "What is quantum noise and decoherence?",
        ],
    },
    {
        "id": "no_cloning",
        "title": "The No-Cloning Theorem",
        "keywords": [("no-cloning", 6), ("no cloning", 6), ("clone a qubit", 5), ("copy a qubit", 5)],
        "beginner": (
            "The **No-Cloning Theorem** proves that no unitary quantum operation can make an exact independent copy of an arbitrary *unknown* quantum state `|ψ⟩` (`U|ψ⟩|0⟩ ≠ |ψ⟩|ψ⟩` for all `|ψ⟩`).\n\n"
            "It follows directly from linearity of quantum evolution: if `U` clones `|0⟩` and `|1⟩`, then on `(|0⟩ + |1⟩)/√2` it produces the **entangled** state `(|00⟩ + |11⟩)/√2`, not the product state `|+⟩|+⟩`.\n\n"
            "This theorem underpins both **Quantum Error Correction** (must use entanglement + syndromes) and **Quantum Cryptography** (eavesdroppers cannot silently copy quantum keys)."
        ),
        "suggestions": [
            "What is Quantum Error Correction?",
            "What is quantum cryptography (QKD)?",
        ],
    },
    {
        "id": "qkd_cryptography",
        "title": "Quantum Cryptography & QKD (BB84)",
        "keywords": [
            ("cryptography", 6), ("qkd", 6), ("bb84", 6), ("key distribution", 5), ("eavesdrop", 4),
        ],
        "beginner": (
            "**Quantum Key Distribution (QKD)** (such as **BB84**) lets two parties generate a shared secret cryptographic key whose security is guaranteed by quantum physics rather than math hardness.\n\n"
            "- Alice encodes random bits in two non-orthogonal bases (`Z` basis `|0⟩,|1⟩` and `X` basis `|+⟩,|−⟩`).\n"
            "- By the **No-Cloning Theorem** and measurement collapse, any eavesdropper (Eve) intercepting qubits in the wrong basis introduces detectable bit errors.\n\n"
            "Note: QKD distributes keys over quantum channels, whereas **Post-Quantum Cryptography (PQC)** uses classical math problems resistant to Shor's algorithm."
        ),
        "suggestions": [
            "What is the No-Cloning Theorem?",
            "What is Shor's algorithm?",
        ],
    },
    {
        "id": "quantum_gates_overview",
        "title": "Quantum Gates, Unitarity & Universal Sets",
        "keywords": [
            ("quantum gate", 5), ("quantum gates", 5), ("gates", 3), ("gate", 2),
            ("unitary", 5), ("universal gate", 5), ("circuit depth", 4), ("reversible", 3),
        ],
        "beginner": (
            "**Quantum Gates** are reversible unitary transformations (`U†U = I`) acting on qubits, preserving total probability.\n\n"
            "- **Pauli (`X, Y, Z`):** `π` rotations (bit flip, combined flip, phase flip).\n"
            "- **Superposition (`H`):** Hadamard maps basis states to equal superpositions.\n"
            "- **Phase (`S, T`) & Rotations (`RX, RY, RZ`):** Adjust relative phases and continuous Bloch angles.\n"
            "- **Multi-qubit (`CX/CNOT, CZ, SWAP, CCX`):** Create conditional logic and entanglement.\n\n"
            "Together, **`{H, T, CNOT}`** form a **universal gate set** able to approximate any quantum computation to arbitrary precision."
        ),
        "suggestions": [
            "Explain the Hadamard gate",
            "Explain the CNOT gate",
            "Explain my circuit",
        ],
    },
    {
        "id": "quantum_computing",
        "title": "What Is Quantum Computing?",
        "keywords": [
            ("quantum computing", 6), ("quantum computer", 6), ("how do quantum", 5),
            ("quantum advantage", 5), ("quantum supremacy", 5), ("quantum vs classical", 5),
        ],
        "beginner": (
            "**Quantum Computing** processes information using quantum-mechanical systems (**qubits**) instead of classical transistors.\n\n"
            "Rather than simply running faster clock speeds, a quantum computer exploits three phenomena:\n"
            "1. **Superposition:** `N` qubits span a `2^N`-amplitude state space.\n"
            "2. **Entanglement:** Correlates qubits across registers in ways classical bits cannot match efficiently.\n"
            "3. **Interference:** Algorithms align phases so right answers amplify and wrong paths cancel.\n\n"
            "**Where it shines:** Quantum chemistry & materials simulation, unstructured search (`O(√N)` via Grover), optimization, and factoring (`Shor`). Classical CPUs remain better for everyday tasks like video, databases, and web apps."
        ),
        "suggestions": [
            "What is a qubit?",
            "What is superposition?",
            "How does entanglement work?",
        ],
    },
    {
        "id": "qiskit_endian",
        "title": "Qiskit Simulators & Bitstring Ordering",
        "keywords": [
            ("qiskit", 6), ("aer", 5), ("little-endian", 6), ("little endian", 6),
            ("bitstring", 5), ("simulator", 4), ("real hardware", 4),
        ],
        "beginner": (
            "QUANTUM LAB runs every circuit on genuine **IBM Qiskit** software simulators (never real physical quantum hardware):\n\n"
            "- **Ideal Mode (`qiskit.quantum_info.Statevector`):** Computes exact complex amplitudes and samples noise-free shots.\n"
            "- **Noisy Mode (`qiskit_aer.AerSimulator`):** Simulates depolarizing gate errors and measurement readout errors.\n\n"
            "**Important bitstring convention:** Qiskit uses **little-endian** ordering, meaning the **rightmost bit is `q0`** and the leftmost bit is `q_{n-1}` (so `|10⟩` means `q1 = 1, q0 = 0`)."
        ),
        "suggestions": [
            "Explain my circuit",
            "Explain my results",
            "What is quantum noise and decoherence?",
        ],
    },
    {
        "id": "physical_hardware",
        "title": "Physical Qubit Hardware Technologies",
        "keywords": [
            ("hardware", 4), ("transmon", 5), ("superconducting", 5), ("trapped ion", 5),
            ("photonic", 5), ("neutral atom", 5), ("made of", 4), ("built physically", 5),
        ],
        "beginner": (
            "Physical qubits can be engineered in several leading hardware platforms (note that QUANTUM LAB itself runs on Qiskit software simulators):\n\n"
            "- **Superconducting Transmons (e.g., IBM, Google):** Micron-scale Josephson junctions cooled to ~15 mK; fast nanosecond gates.\n"
            "- **Trapped Ions (e.g., Quantinuum, IonQ):** Individual charged atoms held by electromagnetic fields and controlled with lasers; very high fidelity and all-to-all connectivity.\n"
            "- **Neutral Atoms, Spin Qubits (Silicon), and Photonics:** Scalable optical-tweezer arrays, semiconductor quantum dots, or room-temperature optical waveguides."
        ),
        "suggestions": [
            "What is a qubit?",
            "What is quantum noise and decoherence?",
        ],
    },
    {
        "id": "algorithm_overview",
        "title": "Quantum Algorithms Overview",
        "keywords": [("algorithm", 5), ("algorithms", 5), ("speedup", 4)],
        "beginner": (
            "**Quantum Algorithms** orchestrate superposition, entanglement, and interference so valid computational paths reinforce constructively while wrong paths cancel.\n\n"
            "- **Grover's Search (`O(√N)`):** Quadratic speedup for unstructured search.\n"
            "- **Shor's & QFT (`O((log N)³)`):** Period finding, phase estimation, and integer factoring.\n"
            "- **Deutsch-Jozsa / Bernstein-Vazirani:** Single-query global function checks.\n"
            "- **VQE & QAOA:** Hybrid variational algorithms for chemistry and optimization on NISQ devices."
        ),
        "suggestions": [
            "How does Grover's search beat classical search?",
            "What is Shor's algorithm?",
            "What are VQE and QAOA?",
        ],
    },
    {
        "id": "experiments_suggest",
        "title": "Suggested Experiments to Try in QUANTUM LAB",
        "keywords": [("suggest an experiment", 8), ("suggest experiment", 6), ("what should i try", 5)],
        "beginner": (
            "Here are five great experiments to build and simulate in **QUANTUM LAB**:\n\n"
            "1. **Equal Superposition (`H` on `q0`):** Observe 50%/50% probabilities and finite-shot variance.\n"
            "2. **Bell State Entanglement (`H` on `q0`, `CX q0→q1`):** Verify `|00⟩` and `|11⟩` correlation, then switch to **Noisy Mode** to observe `|01⟩`/`|10⟩` error leakage.\n"
            "3. **Quantum Interference (`H → Z → H` on `q0`):** Watch destructive interference eliminate `|0⟩` and yield **100% `|1⟩`**.\n"
            "4. **2-Qubit Grover's Search:** Amplify `|11⟩` to 100% in a single oracle + diffusion step.\n"
            "5. **Quantum Teleportation (3 Qubits):** Prepare `RY(π/3)` on `q0` and watch `q2` reproduce its `75% |0⟩ / 25% |1⟩` statistics."
        ),
        "suggestions": [
            "Explain my circuit",
            "How does Grover's search beat classical search?",
            "How does quantum teleportation work?",
        ],
    },
]


_PLACEHOLDER_KEYS = {
    "your_api_key_here",
    "your_gemini_api_key_here",
    "your_openai_api_key_here",
    "your_anthropic_api_key_here",
    "change_me",
    "paste_your_key_here",
    "sk-...",
}


class AITutorService:
    """Generate quantum-computing explanations via a configurable LLM API or Qiskit tutor."""

    @staticmethod
    def is_valid_api_key(key: Optional[str]) -> bool:
        cleaned = (key or "").strip()
        if not cleaned:
            return False
        lowered = cleaned.lower()
        if lowered in _PLACEHOLDER_KEYS or lowered.startswith("your_") or "placeholder" in lowered:
            return False
        return True

    def _get_config(self) -> tuple[str, str, str, str]:
        """Read current provider settings from environment variables."""
        provider = (os.getenv("AI_PROVIDER", "gemini") or "gemini").strip().lower()
        raw_key = (os.getenv("AI_API_KEY", "") or "").strip()
        api_key = raw_key if self.is_valid_api_key(raw_key) else ""
        model = (os.getenv("AI_MODEL", "") or "").strip() or _DEFAULT_MODELS.get(
            provider, "gemini-2.0-flash"
        )
        env_url = (os.getenv("AI_API_URL", "") or "").strip()

        if provider == "gemini":
            api_url = (
                env_url
                or f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
            )
        elif provider == "openai":
            if env_url and "generativelanguage.googleapis.com" not in env_url:
                api_url = env_url
            else:
                api_url = _DEFAULT_URLS["openai"]
        elif provider == "anthropic":
            if env_url and "generativelanguage.googleapis.com" not in env_url:
                api_url = env_url
            else:
                api_url = _DEFAULT_URLS["anthropic"]
        else:
            api_url = env_url

        return provider, api_key, model, api_url

    def update_ai_config(
        self,
        provider: str,
        api_key: str,
        model: Optional[str] = None,
        api_url: Optional[str] = None,
    ) -> dict[str, Any]:
        """Update AI provider credentials in memory and persist them to backend/.env."""
        clean_provider = (provider or "gemini").strip().lower()
        if clean_provider not in _DEFAULT_MODELS:
            raise ValueError(f"Unsupported AI provider '{provider}'.")

        clean_key = re.sub(r"[\r\n]+", "", (api_key or "").strip())
        clean_model = re.sub(r"[\r\n]+", "", (model or "").strip()) or _DEFAULT_MODELS[clean_provider]
        clean_url = re.sub(r"[\r\n]+", "", (api_url or "").strip())

        os.environ["AI_PROVIDER"] = clean_provider
        os.environ["AI_API_KEY"] = clean_key
        os.environ["AI_MODEL"] = clean_model
        os.environ["AI_API_URL"] = clean_url

        env_path = Path(__file__).resolve().parents[2] / ".env"
        example_path = env_path.with_name(".env.example")
        if env_path.exists():
            lines = env_path.read_text(encoding="utf-8").splitlines()
        elif example_path.exists():
            lines = example_path.read_text(encoding="utf-8").splitlines()
        else:
            lines = []

        updates = {
            "AI_PROVIDER": clean_provider,
            "AI_API_KEY": clean_key,
            "AI_MODEL": clean_model,
            "AI_API_URL": clean_url,
        }
        seen: set[str] = set()
        new_lines: list[str] = []
        for line in lines:
            stripped = line.strip()
            matched_key = None
            if stripped and not stripped.startswith("#") and "=" in line:
                candidate = line.split("=", 1)[0].strip()
                if candidate in updates:
                    matched_key = candidate
            if matched_key:
                new_lines.append(f"{matched_key}={updates[matched_key]}")
                seen.add(matched_key)
            else:
                new_lines.append(line)

        for k, v in updates.items():
            if k not in seen:
                new_lines.append(f"{k}={v}")

        env_path.write_text("\n".join(new_lines) + "\n", encoding="utf-8")

        return {
            "ai_configured": self.is_valid_api_key(clean_key),
            "ai_provider": clean_provider,
            "ai_model": clean_model,
        }

    @property
    def api_key(self) -> str:
        return self._get_config()[1]

    @property
    def provider(self) -> str:
        return self._get_config()[0]

    # ------------------------------------------------------------------ #
    #  System prompts                                                      #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _build_system_prompt(context_type: str, level: str) -> str:
        base = (
            "You are Q-ASSIST, an expert quantum computing tutor embedded in QUANTUM LAB, "
            "an interactive scientific laboratory platform. Your explanations must be "
            "clear, accurate, and educational.\n"
            "STRICT SCIENTIFIC RULES:\n"
            "1. Clearly distinguish verified mathematical facts from pedagogical analogies or assumptions.\n"
            "2. NEVER invent simulation results; cite ONLY the provided verified simulator outputs.\n"
            "3. NEVER claim an experiment ran on real quantum hardware — all executions in QUANTUM LAB "
            "run on Qiskit software simulators (ideal statevector or noisy Aer simulator).\n"
            "4. Remember Qiskit uses little-endian bitstring ordering where the rightmost bit is q0.\n\n"
        )

        level_guidance = {
            "beginner": (
                "The student is a beginner. Use simple analogies, avoid jargon, "
                "and explain concepts step by step. Use everyday language."
            ),
            "intermediate": (
                "The student has some quantum computing background. You can use "
                "standard terminology (superposition, entanglement, Bloch sphere) "
                "but still explain non-obvious steps."
            ),
            "advanced": (
                "The student is advanced. You may use mathematical notation, "
                "discuss unitary matrices, reduced density matrices, and error channels "
                "in full rigour."
            ),
        }

        context_guidance = {
            "concept": "Explain the quantum computing concept the student asks about.",
            "circuit": (
                "Analyse the quantum circuit provided. Describe what each gate "
                "does and explain the expected mathematical state evolution."
            ),
            "results": (
                "Interpret the simulation results. Explain the probabilities, "
                "shot counts, statevector amplitudes, and what they reveal about the circuit."
            ),
            "chat": "Have a helpful conversational exchange about quantum computing.",
        }

        return (
            base
            + level_guidance.get(level, level_guidance["beginner"])
            + "\n\n"
            + context_guidance.get(context_type, context_guidance["chat"])
        )

    # ------------------------------------------------------------------ #
    #  Provider-specific HTTP calls                                        #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _format_user_content(
        message: str,
        circuit_config: Optional[dict],
        simulation_results: Optional[dict],
    ) -> str:
        user_parts: list[str] = [message]
        if circuit_config:
            user_parts.append(
                f"\n\nVerified Circuit Configuration:\n```json\n{json.dumps(circuit_config, indent=2)}\n```"
            )
        if simulation_results:
            trimmed_results = dict(simulation_results)
            sv = trimmed_results.get("statevector")
            if isinstance(sv, list) and len(sv) > 32:
                trimmed_results["statevector"] = (
                    f"[{len(sv)} amplitudes omitted for brevity; use probabilities]"
                )
            user_parts.append(
                f"\n\nVerified Qiskit Software Simulator Output:\n```json\n{json.dumps(trimmed_results, indent=2)}\n```"
            )
        return "".join(user_parts)

    async def _call_gemini(
        self,
        api_url: str,
        api_key: str,
        system_prompt: str,
        user_content: str,
        conversation_history: Optional[list[dict]],
    ) -> str:
        contents: list[dict] = []
        if conversation_history:
            for entry in conversation_history[-10:]:
                role = entry.get("role", "user")
                parts_text = entry.get("content", entry.get("text", ""))
                if parts_text:
                    contents.append(
                        {
                            "role": "user" if role == "user" else "model",
                            "parts": [{"text": parts_text}],
                        }
                    )
        contents.append({"role": "user", "parts": [{"text": user_content}]})

        payload = {
            "system_instruction": {"parts": [{"text": system_prompt}]},
            "contents": contents,
            "generationConfig": {
                "temperature": 0.6,
                "maxOutputTokens": 2048,
            },
        }
        url = f"{api_url}?key={api_key}"
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(url, json=payload)
            resp.raise_for_status()
            data = resp.json()

        candidates = data.get("candidates", [])
        if candidates:
            parts = candidates[0].get("content", {}).get("parts", [])
            text = " ".join(p.get("text", "") for p in parts).strip()
            if text:
                return text
        raise ValueError("Empty response from Gemini API.")

    async def _call_openai(
        self,
        api_url: str,
        api_key: str,
        model: str,
        system_prompt: str,
        user_content: str,
        conversation_history: Optional[list[dict]],
    ) -> str:
        messages: list[dict] = [{"role": "system", "content": system_prompt}]
        if conversation_history:
            for entry in conversation_history[-10:]:
                role = entry.get("role", "user")
                text = entry.get("content", entry.get("text", ""))
                if text:
                    messages.append(
                        {
                            "role": "user" if role == "user" else "assistant",
                            "content": text,
                        }
                    )
        messages.append({"role": "user", "content": user_content})

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": model,
            "messages": messages,
            "temperature": 0.6,
            "max_tokens": 2048,
        }
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(api_url, headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()

        choices = data.get("choices", [])
        if choices:
            text = choices[0].get("message", {}).get("content", "").strip()
            if text:
                return text
        raise ValueError("Empty response from OpenAI-compatible API.")

    async def _call_anthropic(
        self,
        api_url: str,
        api_key: str,
        model: str,
        system_prompt: str,
        user_content: str,
        conversation_history: Optional[list[dict]],
    ) -> str:
        messages: list[dict] = []
        if conversation_history:
            for entry in conversation_history[-10:]:
                role = entry.get("role", "user")
                text = entry.get("content", entry.get("text", ""))
                if text:
                    messages.append(
                        {
                            "role": "user" if role == "user" else "assistant",
                            "content": text,
                        }
                    )
        messages.append({"role": "user", "content": user_content})

        headers = {
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }
        payload = {
            "model": model,
            "system": system_prompt,
            "messages": messages,
            "max_tokens": 2048,
        }
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(api_url, headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()

        content_blocks = data.get("content", [])
        text = " ".join(
            b.get("text", "") for b in content_blocks if b.get("type") == "text"
        ).strip()
        if text:
            return text
        raise ValueError("Empty response from Anthropic API.")

    # ------------------------------------------------------------------ #
    #  Public generation entry point                                       #
    # ------------------------------------------------------------------ #

    async def generate_explanation(
        self,
        message: str,
        context_type: str = "chat",
        circuit_config: Optional[dict] = None,
        simulation_results: Optional[dict] = None,
        level: str = "beginner",
        conversation_history: Optional[list[dict]] = None,
    ) -> dict:
        """Return {"explanation": ..., "is_ai_generated": bool, "suggestions": [...]}."""
        provider, api_key, model, api_url = self._get_config()

        if not api_key:
            return self._fallback_explanation(
                message,
                context_type,
                level,
                circuit_config,
                simulation_results,
                fallback_reason="not_configured",
                conversation_history=conversation_history,
            )

        system_prompt = self._build_system_prompt(context_type, level)
        user_content = self._format_user_content(
            message, circuit_config, simulation_results
        )

        try:
            if provider == "gemini":
                explanation = await self._call_gemini(
                    api_url, api_key, system_prompt, user_content, conversation_history
                )
            elif provider == "openai":
                explanation = await self._call_openai(
                    api_url,
                    api_key,
                    model,
                    system_prompt,
                    user_content,
                    conversation_history,
                )
            elif provider == "anthropic":
                explanation = await self._call_anthropic(
                    api_url,
                    api_key,
                    model,
                    system_prompt,
                    user_content,
                    conversation_history,
                )
            else:
                raise ValueError(f"Unsupported AI_PROVIDER '{provider}'.")

            return {
                "explanation": explanation,
                "is_ai_generated": True,
                "suggestions": self._generate_suggestions(context_type, level),
            }

        except Exception as exc:
            logger.error("AI API call (%s) failed: %s", provider, exc)
            return self._fallback_explanation(
                message,
                context_type,
                level,
                circuit_config,
                simulation_results,
                fallback_reason="api_unavailable",
                conversation_history=conversation_history,
            )

    # ------------------------------------------------------------------ #
    #  Circuit-specific helper                                             #
    # ------------------------------------------------------------------ #

    async def explain_circuit(
        self,
        circuit_config: dict,
        simulation_results: Optional[dict] = None,
        level: str = "beginner",
    ) -> dict:
        """High-level helper that formats a circuit explanation prompt."""
        gate_names = [g.get("gate_name", "?") for g in circuit_config.get("gates", [])]
        num_qubits = circuit_config.get("num_qubits", 1)
        message = (
            f"Explain this {num_qubits}-qubit quantum circuit that uses the "
            f"gates: {', '.join(gate_names)}. What does it do and what output "
            f"should we expect?"
        )
        return await self.generate_explanation(
            message=message,
            context_type="circuit",
            circuit_config=circuit_config,
            simulation_results=simulation_results,
            level=level,
        )

    # ------------------------------------------------------------------ #
    #  Circuit diagnostics                                                 #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _diagnose_circuit(circuit_config: dict) -> list[str]:
        """Inspect a circuit structure per qubit for common mistakes."""
        nq = circuit_config.get("num_qubits", 1)
        initial_state = circuit_config.get("initial_state") or ("0" * nq)
        gates = circuit_config.get("gates", [])
        issues: list[str] = []

        if not gates:
            issues.append(
                "Your circuit has no gates yet — all qubits remain in their initial computational basis state."
            )
            return issues

        definitely_zero = [
            (initial_state[q] == "0") if q < len(initial_state) else True
            for q in range(nq)
        ]
        last_1q: dict[int, str] = {}
        last_multi_sig: Optional[tuple] = None

        for idx, g in enumerate(gates):
            name = (g.get("gate_name") or "").upper()
            if name == "CNOT":
                name = "CX"
            elif name == "TOFFOLI":
                name = "CCX"
            targets = g.get("target_qubits") or []
            controls = g.get("control_qubits") or []

            if len(controls) == 0 and len(targets) == 1:
                q = targets[0]
                if name in ("H", "X", "Y", "Z") and last_1q.get(q) == name:
                    issues.append(
                        f"Steps around gate #{idx + 1}: consecutive `{name}` gates on `q{q}` cancel out (`{name}² = I`)."
                    )
                    last_1q.pop(q, None)
                elif name == "S" and last_1q.get(q) == "S":
                    issues.append(
                        f"Gate #{idx + 1}: two consecutive `S` gates on `q{q}` simplify to a single `Z` gate (`S² = Z`)."
                    )
                    last_1q[q] = name
                else:
                    last_1q[q] = name
                last_multi_sig = None

                if name not in ("I", "Z", "S", "T", "RZ"):
                    if 0 <= q < nq:
                        definitely_zero[q] = False
            else:
                sig = (name, tuple(controls), tuple(targets))
                if name in ("CX", "CZ", "SWAP", "CCX") and sig == last_multi_sig:
                    issues.append(
                        f"Gate #{idx + 1}: consecutive identical `{name}` gates on the same qubits cancel out (`{name}² = I`)."
                    )
                    last_multi_sig = None
                else:
                    last_multi_sig = sig

                if name in ("CX", "CZ", "CCX"):
                    inactive = [
                        f"q{c}" for c in controls if 0 <= c < nq and definitely_zero[c]
                    ]
                    if inactive:
                        issues.append(
                            f"Gate #{idx + 1} (`{name}`): control qubit(s) {', '.join(inactive)} are still deterministically `|0⟩`, so the controlled operation will not trigger. Apply `X` or `H` to excite the control first."
                        )

                for q in controls + targets:
                    last_1q.pop(q, None)
                if name == "CX" and controls and targets:
                    c0, t0 = controls[0], targets[0]
                    if 0 <= c0 < nq and 0 <= t0 < nq and not definitely_zero[c0]:
                        definitely_zero[t0] = False
                elif name == "SWAP" and len(targets) == 2:
                    a, b = targets
                    if 0 <= a < nq and 0 <= b < nq:
                        definitely_zero[a], definitely_zero[b] = (
                            definitely_zero[b],
                            definitely_zero[a],
                        )
                elif name == "CCX" and len(controls) == 2 and targets:
                    c0, c1, t0 = controls[0], controls[1], targets[0]
                    if (
                        0 <= c0 < nq
                        and 0 <= c1 < nq
                        and 0 <= t0 < nq
                        and not definitely_zero[c0]
                        and not definitely_zero[c1]
                    ):
                        definitely_zero[t0] = False

        if not issues:
            issues.append(
                "No structural redundancies or inactive-control issues detected. Note: Qiskit labels bitstrings in little-endian order (rightmost bit is q0)."
            )
        return issues

    # ------------------------------------------------------------------ #
    #  Live Qiskit circuit evaluation helper                               #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _format_complex(z: complex) -> str:
        re_val, im_val = z.real, z.imag
        if abs(im_val) < 1e-6:
            return f"{re_val:+.3f}".lstrip("+") if re_val >= 0 else f"{re_val:.3f}"
        if abs(re_val) < 1e-6:
            return f"{im_val:.3f}i"
        sign = "+" if im_val >= 0 else "−"
        return f"({re_val:.3f}{sign}{abs(im_val):.3f}i)"

    @classmethod
    def _format_dirac_ket(cls, sv_array: Any, num_qubits: int, max_terms: int = 8) -> str:
        terms: list[tuple[float, str, complex]] = []
        for idx, amp in enumerate(sv_array):
            prob = float(abs(amp) ** 2)
            if prob > 1e-6:
                terms.append((prob, format(idx, f"0{num_qubits}b"), complex(amp)))
        if not terms:
            return f"|{'0' * num_qubits}⟩"
        terms.sort(key=lambda item: (-item[0], item[1]))
        shown = terms[:max_terms]
        parts: list[str] = []
        for i, (_, bits, amp) in enumerate(shown):
            coef = cls._format_complex(amp)
            if i == 0:
                parts.append(f"{coef}|{bits}⟩")
            elif coef.startswith("-"):
                parts.append(f" − {coef[1:]}|{bits}⟩")
            else:
                parts.append(f" + {coef}|{bits}⟩")
        suffix = f" + … ({len(terms) - max_terms} more)" if len(terms) > max_terms else ""
        return "".join(parts) + suffix

    @staticmethod
    def _format_gate_call(gate: dict) -> str:
        name = gate.get("gate_name", "?")
        qubits = [str(q) for q in (gate.get("control_qubits") or []) + (gate.get("target_qubits") or [])]
        params = gate.get("parameters") or {}
        if "angle" in params:
            return f"{name}({','.join(qubits)}; θ={float(params['angle']):.3f})"
        return f"{name}({','.join(qubits)})"

    def _analyze_circuit_with_qiskit(
        self,
        circuit_config: dict,
        simulation_results: Optional[dict],
        msg_lower: str,
        context_type: str,
        level: str,
        prefix: str = "",
    ) -> dict:
        """Compute verified statevector evolution, probabilities, entanglement, and diagnostics."""
        from ..quantum.simulator import QuantumSimulator
        from ..schemas.circuit import CircuitConfig

        nq = int(circuit_config.get("num_qubits", 1) or 1)
        init_state = circuit_config.get("initial_state") or ("0" * nq)
        gates = circuit_config.get("gates") or []
        gate_summary = ", ".join(self._format_gate_call(g) for g in gates) or "None (identity circuit)"

        lines: list[str] = []
        if prefix:
            lines.append(prefix)

        lines.append(
            f"### Verified Circuit Summary\n"
            f"- **Qubits:** {nq} (Hilbert space dimension `2^{nq} = {1 << nq}`)\n"
            f"- **Initial Basis State:** `|{init_state}⟩` (qubit order `q0..q{nq - 1}`, Qiskit little-endian bitstrings)\n"
            f"- **Gate Sequence ({len(gates)} gates):** `{gate_summary}`\n"
        )

        # Evaluate exact statevector with Qiskit
        sv_array = None
        probs: dict[str, float] = {}
        qc = None
        sim = QuantumSimulator()
        try:
            from qiskit.quantum_info import Statevector, partial_trace

            cfg = CircuitConfig(
                num_qubits=nq,
                gates=gates,
                initial_state=circuit_config.get("initial_state"),
            )
            errors = sim.validate_circuit(cfg)
            if not errors:
                qc = sim.build_circuit(cfg)
                sv_obj = Statevector.from_instruction(qc)
                sv_array = list(sv_obj.data)
                for idx, amp in enumerate(sv_array):
                    p = float(abs(amp) ** 2)
                    if p > 1e-6:
                        probs[format(idx, f"0{nq}b")] = p

                # Step-by-step evolution for small circuits
                if gates and nq <= 5 and len(gates) <= 12:
                    lines.append("### Step-by-Step State Evolution (Qiskit Statevector)")
                    step_cfg = CircuitConfig(
                        num_qubits=nq, gates=[], initial_state=circuit_config.get("initial_state")
                    )
                    for step_idx, g in enumerate(gates, start=1):
                        step_cfg = CircuitConfig(
                            num_qubits=nq,
                            gates=gates[:step_idx],
                            initial_state=circuit_config.get("initial_state"),
                        )
                        step_sv = Statevector.from_instruction(sim.build_circuit(step_cfg))
                        ket = self._format_dirac_ket(step_sv.data, nq, max_terms=6)
                        lines.append(
                            f"{step_idx}. `{self._format_gate_call(g)}` → `{ket}`"
                        )
                    lines.append("")

                final_ket = self._format_dirac_ket(sv_array, nq)
                lines.append(f"**Final Quantum State:** `|ψ⟩ = {final_ket}`\n")

                # Entanglement / purity check for multi-qubit circuits
                if nq >= 2:
                    entangled_qubits: list[str] = []
                    for q in range(nq):
                        trace_out = [i for i in range(nq) if i != q]
                        rho_q = partial_trace(sv_obj, trace_out)
                        purity = float(rho_q.purity().real)
                        if purity < 0.999:
                            entangled_qubits.append(f"`q{q}` (purity `{purity:.2f}`)")
                    if entangled_qubits:
                        lines.append(
                            f"- **Entanglement Detected:** {', '.join(entangled_qubits)} have purity `< 1.0`, "
                            "confirming the qubits are entangled and non-separable (use the **Q-Sphere** rather than single-qubit Bloch spheres).\n"
                        )
                    elif gates:
                        lines.append(
                            "- **Separability:** Each qubit remains in a pure single-qubit state (purity `1.00`, no cross-qubit entanglement).\n"
                        )

                # Phases explanation if specifically asked
                if any(w in msg_lower for w in ("phase", "phases", "statevector")):
                    lines.append("### Statevector Amplitudes & Relative Phases")
                    for idx, amp in enumerate(sv_array):
                        p = float(abs(amp) ** 2)
                        if p > 1e-6:
                            bits = format(idx, f"0{nq}b")
                            ang_deg = math.degrees(math.atan2(amp.imag, amp.real))
                            lines.append(
                                f"- **|{bits}⟩:** amplitude `{self._format_complex(amp)}`, probability `{p * 100:.2f}%`, phase `{ang_deg:+.1f}°`"
                            )
                    lines.append(
                        "\n*Note:* Relative phase differences between basis states drive constructive/destructive interference in subsequent gates, while an overall global phase does not affect measurement outcomes.\n"
                    )

        except Exception as exc:
            logger.debug("Qiskit circuit analysis skipped: %s", exc)

        # Ideal probabilities vs sampled counts vs noise analysis
        if probs:
            lines.append("### Expected Theoretical Probabilities (Ideal Qiskit Statevector)")
            for state, prob in sorted(probs.items(), key=lambda kv: kv[1], reverse=True)[:8]:
                lines.append(f"- **|{state}⟩:** `{prob * 100:.2f}%`")
            lines.append("")

        wants_noise = any(
            w in msg_lower for w in ("noise", "noisy", "ideal vs", "error", "decoher")
        )
        if wants_noise and qc is not None and nq <= 6:
            try:
                noisy = sim.simulate_noisy(qc, 1024, nq, gate_error=0.02, measurement_error=0.02, seed=42)
                noisy_probs = noisy.get("probabilities", {})
                lines.append(
                    "### Ideal vs. Noisy Execution Preview (`AerSimulator`, 1024 shots, 2% gate & readout error)"
                )
                all_states = sorted(
                    set(probs.keys()) | set(noisy_probs.keys()),
                    key=lambda s: max(probs.get(s, 0.0), noisy_probs.get(s, 0.0)),
                    reverse=True,
                )[:8]
                for s in all_states:
                    ip = probs.get(s, 0.0) * 100
                    np_val = noisy_probs.get(s, 0.0) * 100
                    tag = " *(noise leakage)*" if probs.get(s, 0.0) < 1e-6 and np_val > 0 else ""
                    lines.append(f"- **|{s}⟩:** Ideal `{ip:.2f}%` vs. Noisy `{np_val:.2f}%`{tag}")
                lines.append(
                    f"\nCircuit depth is `{qc.depth()}`: depolarizing gate errors and readout bit-flips shift probability away from ideal peaks into off-target bitstrings.\n"
                )
            except Exception as exc:
                logger.debug("Noisy comparison preview failed: %s", exc)

        if simulation_results:
            mode = simulation_results.get("simulation_mode", "ideal")
            sim_probs = simulation_results.get("probabilities", {})
            meas = simulation_results.get("measurements", {})
            meta = simulation_results.get("metadata", {}) or {}
            total_shots = sum(meas.values()) if meas else 0
            backend_name = meta.get("backend", "Qiskit software simulator")
            lines.append(
                f"### Your Last Simulator Run (`{backend_name}` — `{mode.upper()}` mode)"
            )
            if sim_probs:
                for state, prob in sorted(sim_probs.items(), key=lambda kv: kv[1], reverse=True)[:8]:
                    cnt = meas.get(state, 0)
                    lines.append(
                        f"- **|{state}⟩:** observed `{prob * 100:.2f}%` (`{cnt}/{total_shots}` shots)"
                    )
            if total_shots and mode == "ideal":
                lines.append(
                    f"\n*Sampling Variance Note:* Across `{total_shots}` shots, finite random sampling fluctuates by roughly `±√(p(1−p)/{total_shots})` around exact theoretical probabilities."
                )
            elif mode == "noisy" and meta.get("ideal_probabilities"):
                lines.append(
                    f"\n*Noisy vs. Ideal:* Configured `gate_error={meta.get('gate_error', 0.01)}` and "
                    f"`measurement_error={meta.get('measurement_error', 0.01)}` introduce probability leakage relative to the ideal distribution."
                )
            lines.append("")

        if "debug" in msg_lower or context_type == "circuit" or "mistake" in msg_lower or "cancel" in msg_lower:
            issues = self._diagnose_circuit(circuit_config)
            lines.append("### Circuit Diagnostics\n" + "\n".join(f"- {i}" for i in issues) + "\n")

        lines.append(
            "*All values above are computed on Qiskit software simulators, not physical quantum hardware.*"
        )

        return {
            "explanation": "\n".join(lines),
            "is_ai_generated": False,
            "suggestions": self._generate_suggestions(
                "results" if simulation_results and context_type == "results" else "circuit",
                level,
            ),
        }

    # ------------------------------------------------------------------ #
    #  Gate & Knowledge-Base Matching                                      #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _format_gate_matrix(matrix: Any) -> str:
        if not isinstance(matrix, list):
            return ""
        rows = []
        for row in matrix:
            cells = []
            for re_v, im_v in row:
                if abs(im_v) < 1e-6:
                    cells.append(f"{re_v:.3f}".rstrip("0").rstrip(".") if "." in f"{re_v:.3f}" else str(re_v))
                elif abs(re_v) < 1e-6:
                    cells.append(f"{im_v:+.3g}i".lstrip("+"))
                else:
                    cells.append(f"{re_v:.2f}{im_v:+.2f}i")
            rows.append("[ " + ",  ".join(cells) + " ]")
        return "\n".join(rows)

    def _match_gate_question(self, msg_lower: str, level: str, prefix: str = "") -> Optional[dict]:
        from ..quantum.gates import GATE_INFO

        matched: list[str] = []
        for symbol, meta in _GATE_DETAILS.items():
            if re.search(meta["patterns"], msg_lower):
                matched.append(symbol)

        if not matched:
            return None

        sections: list[str] = []
        if prefix:
            sections.append(prefix)

        for symbol in matched[:3]:
            info = GATE_INFO.get(symbol, {})
            det = _GATE_DETAILS[symbol]
            block = [
                f"### {info.get('name', symbol)} (`{info.get('symbol', symbol)}`)",
                info.get("description", ""),
                f"- **Action:** {det['action']}",
                f"- **Geometry / Circuit Role:** {det['bloch']}",
            ]
            if level in ("intermediate", "advanced") and isinstance(info.get("matrix"), list):
                block.append(f"**Unitary Matrix:**\n```\n{self._format_gate_matrix(info['matrix'])}\n```")
            sections.append("\n".join(block))

        return {
            "explanation": "\n\n".join(sections),
            "is_ai_generated": False,
            "suggestions": [
                "Explain my circuit",
                "What is a universal gate set?",
                "How does entanglement work?",
            ],
        }

    @staticmethod
    def _score_topics(msg_lower: str) -> list[tuple[int, dict[str, Any]]]:
        scored: list[tuple[int, dict[str, Any]]] = []
        for topic in _KNOWLEDGE_TOPICS:
            score = 0
            for kw, weight in topic["keywords"]:
                if len(kw) <= 3:
                    if re.search(rf"\b{re.escape(kw)}\b", msg_lower):
                        score += weight
                elif kw in msg_lower:
                    score += weight
            if score > 0:
                scored.append((score, topic))
        scored.sort(key=lambda item: item[0], reverse=True)
        return scored

    @staticmethod
    def _render_topic(topic: dict[str, Any], level: str) -> str:
        body = topic["beginner"]
        if level in ("intermediate", "advanced") and topic.get("advanced"):
            body = f"{body}\n\n**Deeper Detail ({level.capitalize()}):**\n{topic['advanced']}"
        return f"### {topic['title']}\n{body}"

    @staticmethod
    def _search_curriculum(msg_lower: str) -> Optional[dict]:
        from .learning_service import CURRICULUM

        stop = {
            "what", "is", "are", "how", "does", "do", "why", "can", "the", "a", "an",
            "of", "in", "to", "for", "and", "or", "with", "explain", "tell", "me", "about",
        }
        tokens = [t for t in re.findall(r"[a-z0-9]{3,}", msg_lower) if t not in stop]
        if not tokens:
            return None

        best_score = 0
        best_lesson = None
        for mod in CURRICULUM:
            for lesson in mod.lessons:
                haystack = (
                    lesson.title
                    + " "
                    + lesson.description
                    + " "
                    + " ".join(c.content for c in lesson.content if c.type != "circuit")
                ).lower()
                score = sum(
                    3 if tok in lesson.title.lower() else (1 if tok in haystack else 0)
                    for tok in tokens
                )
                if score > best_score:
                    best_score = score
                    best_lesson = lesson

        if not best_lesson or best_score < 2:
            return None

        parts = [f"### {best_lesson.title}", best_lesson.description]
        for block in best_lesson.content:
            if block.type == "text":
                parts.append(block.content)
            elif block.type == "formula":
                parts.append(f"**Key Formula:** `{block.content}`")
        return {
            "explanation": "\n\n".join(parts),
            "is_ai_generated": False,
            "suggestions": [
                "What is superposition?",
                "How does entanglement work?",
                "Explain my circuit",
            ],
        }

    # ------------------------------------------------------------------ #
    #  Fallback Tutor Engine                                               #
    # ------------------------------------------------------------------ #

    def _fallback_explanation(
        self,
        message: str,
        context_type: str,
        level: str,
        circuit_config: Optional[dict] = None,
        simulation_results: Optional[dict] = None,
        fallback_reason: str = "not_configured",
        conversation_history: Optional[list[dict]] = None,
    ) -> dict:
        """Answer user questions directly using Qiskit simulation and the curated knowledge base."""
        msg_lower = (message or "").strip().lower()
        prefix = ""
        if fallback_reason == "api_unavailable":
            prefix = (
                "> *Note: External LLM API could not be reached — answering using Qiskit simulator analysis and local physics references.*\n\n"
            )

        # 1. Conversational greetings / identity / help
        if re.fullmatch(r"(hi|hello|hey|good morning|good evening|greetings)[!?. ]*", msg_lower):
            return {
                "explanation": (
                    f"{prefix}Hello! I'm **Q-ASSIST**, your quantum computing guide inside **QUANTUM LAB**. "
                    "Ask me about any quantum concept (qubits, superposition, entanglement, Grover's, Shor's, teleportation, noise), "
                    "any gate (`H`, `X`, `CNOT`, `RZ`, `Toffoli`), or ask me to analyze your active circuit."
                ),
                "is_ai_generated": False,
                "suggestions": self._generate_suggestions("chat", level),
            }

        if any(p in msg_lower for p in ("who are you", "what are you", "what can you do", "help me")):
            return {
                "explanation": (
                    f"{prefix}I'm **Q-ASSIST**, your interactive quantum computing tutor. I can:\n"
                    "- **Explain quantum concepts** (qubits, superposition, entanglement, interference, Bloch/Q-spheres, algorithms, noise, QEC).\n"
                    "- **Explain any gate** in the palette (`I, X, Y, Z, H, S, T, RX, RY, RZ, CX/CNOT, CZ, SWAP, CCX`).\n"
                    "- **Analyze and debug your active circuit** step-by-step using live Qiskit statevector evaluation.\n"
                    "- **Interpret simulation outputs** and compare ideal vs. noisy execution."
                ),
                "is_ai_generated": False,
                "suggestions": self._generate_suggestions("chat", level),
            }

        if re.fullmatch(r"(thanks|thank you|thx|ok|okay|got it|cool|nice)[!?. ]*", msg_lower):
            return {
                "explanation": f"{prefix}You're welcome! Ask anytime if you want to explore another quantum concept or test a new circuit.",
                "is_ai_generated": False,
                "suggestions": self._generate_suggestions("chat", level),
            }

        # 2. Circuit / simulation-specific questions (runs live Qiskit Statevector & diagnostics)
        circuit_phrases = (
            "my circuit", "this circuit", "current circuit", "my result", "simulation result",
            "debug", "expected probabilit", "output probabilit", "what output",
            "ideal vs", "noisy execution", "noise affect", "shot counts differ",
            "statevector phases", "analyse my", "analyze my", "explain circuit",
        )
        wants_circuit = (
            context_type in ("circuit", "results")
            or any(p in msg_lower for p in circuit_phrases)
        )
        # Specific conceptual questions about shot variance or phases without an attached simulation
        if "shot counts differ" in msg_lower and not simulation_results:
            wants_circuit = False
        if "statevector phases tell us" in msg_lower and not (circuit_config and circuit_config.get("gates")):
            wants_circuit = False
        if "why can't a bloch sphere" in msg_lower or "bloch sphere show an entangled" in msg_lower:
            wants_circuit = False

        if wants_circuit and (circuit_config or simulation_results):
            return self._analyze_circuit_with_qiskit(
                circuit_config or {"num_qubits": 1, "gates": []},
                simulation_results,
                msg_lower,
                context_type,
                level,
                prefix=prefix,
            )

        # 3. Handle comparison questions ("difference between X and Y", "compare X and Y", "X vs Y")
        is_comparison = any(
            c in msg_lower for c in ("difference between", "compare ", " vs ", " versus ", "differ from")
        )
        scored_topics = self._score_topics(msg_lower)
        if is_comparison and len(scored_topics) >= 2:
            t1 = scored_topics[0][1]
            t2 = scored_topics[1][1]
            if t1["id"] != t2["id"]:
                return {
                    "explanation": (
                        f"{prefix}## Comparing {t1['title']} vs. {t2['title']}\n\n"
                        f"{self._render_topic(t1, level)}\n\n---\n\n{self._render_topic(t2, level)}"
                    ),
                    "is_ai_generated": False,
                    "suggestions": t1["suggestions"][:2] + t2["suggestions"][:1],
                }

        # 4. Specific gate questions (unless a higher-level topic like Bloch sphere/superposition dominates strongly)
        top_topic_score = scored_topics[0][0] if scored_topics else 0
        gate_reply = self._match_gate_question(msg_lower, level, prefix=prefix)
        if gate_reply and top_topic_score < 6:
            return gate_reply

        # 5. Best-matching topic in Knowledge Base
        if scored_topics:
            best = scored_topics[0][1]
            return {
                "explanation": f"{prefix}{self._render_topic(best, level)}",
                "is_ai_generated": False,
                "suggestions": best["suggestions"],
            }

        if gate_reply:
            return gate_reply

        # 6. Search Learning Academy curriculum lessons
        curriculum_reply = self._search_curriculum(msg_lower)
        if curriculum_reply:
            if prefix:
                curriculum_reply["explanation"] = prefix + curriculum_reply["explanation"]
            return curriculum_reply

        # 7. Contextual follow-up ("tell me more", "example", "why?") using previous turn
        if conversation_history and any(
            p in msg_lower for p in ("more", "example", "explain again", "simpler", "detail", "why?")
        ):
            last_text = " ".join(
                (m.get("content") or "") for m in conversation_history[-2:]
            ).lower()
            prev_topics = self._score_topics(last_text)
            if prev_topics:
                topic = prev_topics[0][1]
                return {
                    "explanation": f"{prefix}{self._render_topic(topic, 'advanced' if 'detail' in msg_lower else level)}",
                    "is_ai_generated": False,
                    "suggestions": topic["suggestions"],
                }

        # 8. Out-of-scope or unrecognized phrasing — acknowledge the actual question cleanly
        return {
            "explanation": (
                f"{prefix}I didn't find a direct quantum-computing match for **\"{message.strip()}\"** in my offline reference engine "
                "(live open-domain LLM answers require setting `AI_API_KEY` in `backend/.env`).\n\n"
                "Try asking me directly about:\n"
                "- **Concepts:** qubits, superposition, entanglement, interference, measurement, Bloch sphere, Q-Sphere, Dirac notation, or decoherence\n"
                "- **Gates & Circuits:** Hadamard (`H`), `CNOT`/`CX`, Pauli `X/Y/Z`, `RX/RY/RZ`, Toffoli, or **\"Explain / Debug my circuit\"**\n"
                "- **Algorithms:** Grover's search, Shor's algorithm, QFT, Quantum Teleportation, VQE/QAOA, or Quantum Error Correction."
            ),
            "is_ai_generated": False,
            "suggestions": [
                "What is a qubit?",
                "How does quantum teleportation work?",
                "Explain the Hadamard gate",
                "Explain my circuit",
            ],
        }

    # ------------------------------------------------------------------ #
    #  Suggestions                                                         #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _generate_suggestions(context_type: str, level: str) -> list[str]:
        suggestions_map = {
            "concept": [
                "What is superposition?",
                "How does entanglement work?",
                "Why can't a Bloch sphere show an entangled Bell state?",
                "How does Grover's search beat classical search?",
            ],
            "circuit": [
                "Debug my circuit for mistakes or cancellations",
                "What output probabilities should I expect?",
                "How would noise affect this circuit?",
            ],
            "results": [
                "Why do shot counts differ slightly from theoretical probabilities?",
                "What do the statevector phases tell us?",
                "Compare ideal vs. noisy execution for this circuit",
            ],
            "chat": [
                "Explain my circuit",
                "What is a qubit?",
                "Suggest an experiment",
                "How does quantum teleportation work?",
            ],
        }
        return suggestions_map.get(context_type, suggestions_map["chat"])
