"""Pydantic v2 schemas for authentication and user profiles."""

from __future__ import annotations

from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class RegisterRequest(BaseModel):
    """Payload to register a new Quantum Lab account."""

    name: str
    email: str
    password: str
    role: str = "Student"
    institution: str = "Quantum Lab Workspace"


class LoginRequest(BaseModel):
    """Payload to sign in with email and password."""

    email: str
    password: str


class ProfileUpdateRequest(BaseModel):
    """Payload to update an authenticated user's profile."""

    name: Optional[str] = None
    role: Optional[str] = None
    institution: Optional[str] = None


class UserPublic(BaseModel):
    """Public user representation (never exposes password hashes)."""

    id: int
    name: str
    email: str
    role: str
    institution: str
    is_demo: bool
    created_at: datetime
    last_login_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class AuthResponse(BaseModel):
    """Token and user profile returned on sign-in or registration."""

    access_token: str
    token_type: str = "bearer"
    user: UserPublic
