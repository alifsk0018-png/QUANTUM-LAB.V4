import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function serveOrtStatic() {
  const ortDir = path.resolve(__dirname, 'public', 'ort');
  const mimeByExt = {
    '.mjs': 'application/javascript; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.wasm': 'application/wasm',
  };
  return {
    name: 'serve-ort-static',
    configureServer(server) {
      server.middlewares.use('/ort', (req, res, next) => {
        const cleanUrl = (req.url || '').split('?')[0];
        const fileName = path.basename(cleanUrl);
        if (!fileName) return next();
        const filePath = path.join(ortDir, fileName);
        if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
          return next();
        }
        const ext = path.extname(fileName).toLowerCase();
        res.setHeader('Content-Type', mimeByExt[ext] || 'application/octet-stream');
        fs.createReadStream(filePath).pipe(res);
      });
    },
  };
}

export default defineConfig({
  plugins: [serveOrtStatic(), react()],
  resolve: {
    alias: {
      'plotly.js': 'plotly.js-dist-min',
    },
  },
  optimizeDeps: {
    include: ['plotly.js-dist-min'],
    exclude: ['@huggingface/transformers', 'onnxruntime-web'],
  },
  build: {
    chunkSizeWarningLimit: 1200,
  },
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8000',
        changeOrigin: true,
      },
    },
  },
});
