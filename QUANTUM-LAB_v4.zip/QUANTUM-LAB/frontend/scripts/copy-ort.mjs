/**
 * Copies ONNX Runtime WebAssembly files from installed node_modules into
 * public/ort/ so the in-browser Whisper worker works offline and in deploy builds
 * without committing 32 MB of binary WASM files into source zips.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.resolve(__dirname, '..');
const targetDir = path.join(rootDir, 'public', 'ort');

const sources = [
  path.join(rootDir, 'node_modules', '@huggingface', 'transformers', 'dist'),
  path.join(rootDir, 'node_modules', 'onnxruntime-web', 'dist'),
];

fs.mkdirSync(targetDir, { recursive: true });

let copied = 0;
for (const srcDir of sources) {
  if (!fs.existsSync(srcDir)) continue;
  for (const name of fs.readdirSync(srcDir)) {
    if (name.startsWith('ort-wasm-simd-threaded') && (name.endsWith('.wasm') || name.endsWith('.mjs'))) {
      fs.copyFileSync(path.join(srcDir, name), path.join(targetDir, name));
      copied += 1;
    }
  }
}

console.log(`[copy-ort] Synced ${copied} ONNX Runtime asset(s) to public/ort/`);
