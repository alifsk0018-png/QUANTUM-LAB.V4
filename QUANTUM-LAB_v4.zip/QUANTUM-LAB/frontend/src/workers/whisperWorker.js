/* eslint-disable no-restricted-globals */
/**
 * Web Worker: in-browser Whisper speech-to-text for Q-ASSIST voice questions.
 * Runs on WebAssembly via Transformers.js, so it works in any modern browser
 * (including embedded ones without a cloud speech service) and needs no
 * native libraries on the host machine.
 */
import { pipeline, env } from '@huggingface/transformers';

const MODEL_ID = 'onnx-community/whisper-tiny.en';
const LOCAL_MODEL_ROOT = '/models/';

// Quantum vocabulary is common in this app; fix frequent mishearings.
const FIXES = [
  [/\bhadam(?:ar|er|aard)d?\b/gi, 'Hadamard'],
  [/\bc ?not\b|\bsee not\b/gi, 'CNOT'],
  [/\bcue ?bits?\b|\bq bits?\b|\bcubits?\b/gi, (m) => (m.toLowerCase().endsWith('s') ? 'qubits' : 'qubit')],
  [/\bkiss ?kit\b|\bqis ?kit\b/gi, 'Qiskit'],
  [/\bbloc(?:k|h)? sphere\b/gi, 'Bloch sphere'],
  [/\bgrovers?\b/gi, "Grover's"],
];

let transcriberPromise = null;

async function hasLocalModel() {
  try {
    const res = await fetch(`${LOCAL_MODEL_ROOT}${MODEL_ID}/config.json`, { method: 'GET' });
    return res.ok && (res.headers.get('content-type') || '').includes('json');
  } catch {
    return false;
  }
}

async function getTranscriber() {
  if (!transcriberPromise) {
    transcriberPromise = (async () => {
      const local = await hasLocalModel();
      env.allowLocalModels = local;
      env.localModelPath = LOCAL_MODEL_ROOT;
      env.allowRemoteModels = !local;
      // Serve the ONNX Runtime WebAssembly binaries from our own origin.
      env.backends.onnx.wasm.wasmPaths = '/ort/';
      env.backends.onnx.wasm.numThreads = 1;

      return pipeline('automatic-speech-recognition', MODEL_ID, {
        dtype: 'q8',
        device: 'wasm',
        progress_callback: (p) => {
          if (p.status === 'progress' && p.total) {
            self.postMessage({ type: 'progress', file: p.file, progress: p.progress });
          }
        },
      });
    })().catch((err) => {
      transcriberPromise = null;
      throw err;
    });
  }
  return transcriberPromise;
}

self.addEventListener('message', async (event) => {
  const { type, id, audio } = event.data || {};
  try {
    if (type === 'load') {
      await getTranscriber();
      self.postMessage({ type: 'ready' });
      return;
    }
    if (type === 'transcribe') {
      const transcriber = await getTranscriber();
      const output = await transcriber(audio, {
        chunk_length_s: 30,
        stride_length_s: 5,
      });
      let text = (output?.text || '').replace(/\[[^\]]*\]|\([^)]*\)/g, ' ').replace(/\s+/g, ' ').trim();
      for (const [re, rep] of FIXES) text = text.replace(re, rep);
      self.postMessage({ type: 'result', id, text });
    }
  } catch (err) {
    self.postMessage({ type: 'error', id, message: err?.message || String(err) });
  }
});
