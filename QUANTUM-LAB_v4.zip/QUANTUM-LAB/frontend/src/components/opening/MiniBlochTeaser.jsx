import React, { useMemo, useState } from 'react';
import { RotateCcw, Sparkles } from 'lucide-react';

const INV_SQRT2 = 1 / Math.SQRT2;
const COS_PI8 = Math.cos(Math.PI / 4);
const SIN_PI8 = Math.sin(Math.PI / 4);

const INITIAL_STATE = {
  alpha: [1, 0], // [re, im]
  beta: [0, 0],
};

function cMul([ar, ai], [br, bi]) {
  return [ar * br - ai * bi, ar * bi + ai * br];
}

function cAdd([ar, ai], [br, bi]) {
  return [ar + br, ai + bi];
}

function cSub([ar, ai], [br, bi]) {
  return [ar - br, ai - bi];
}

function cScale([r, i], s) {
  return [r * s, i * s];
}

function cAbs2([r, i]) {
  return r * r + i * i;
}

function applySingleQubitGate(state, gate) {
  const { alpha: a, beta: b } = state;
  let nextA = a;
  let nextB = b;

  switch (gate) {
    case 'H':
      nextA = cScale(cAdd(a, b), INV_SQRT2);
      nextB = cScale(cSub(a, b), INV_SQRT2);
      break;
    case 'X':
      nextA = b;
      nextB = a;
      break;
    case 'Y':
      // Y = [[0, -i], [i, 0]]
      nextA = cMul([0, -1], b);
      nextB = cMul([0, 1], a);
      break;
    case 'Z':
      nextA = a;
      nextB = [-b[0], -b[1]];
      break;
    case 'T':
      nextA = a;
      nextB = cMul([COS_PI8, SIN_PI8], b);
      break;
    default:
      break;
  }

  const norm = Math.sqrt(cAbs2(nextA) + cAbs2(nextB)) || 1;
  return {
    alpha: cScale(nextA, 1 / norm),
    beta: cScale(nextB, 1 / norm),
  };
}

function formatComplex([r, i]) {
  const rr = Math.abs(r) < 1e-3 ? 0 : r;
  const ii = Math.abs(i) < 1e-3 ? 0 : i;
  if (rr === 0 && ii === 0) return '0';
  if (ii === 0) return rr.toFixed(2);
  if (rr === 0) {
    if (Math.abs(ii - 1) < 1e-3) return 'i';
    if (Math.abs(ii + 1) < 1e-3) return '-i';
    return `${ii.toFixed(2)}i`;
  }
  const sign = ii >= 0 ? '+' : '-';
  return `(${rr.toFixed(2)}${sign}${Math.abs(ii).toFixed(2)}i)`;
}

function classifyBlochState(bx, by, bz) {
  if (bz > 0.96) return 'Ground |0⟩';
  if (bz < -0.96) return 'Excited |1⟩';
  if (bx > 0.96) return 'Superposition |+⟩';
  if (bx < -0.96) return 'Superposition |−⟩';
  if (by > 0.96) return 'Circular |+i⟩';
  if (by < -0.96) return 'Circular |−i⟩';
  if (Math.abs(bz) < 0.08) return 'Equatorial Phase State';
  return 'Coherent Qubit State';
}

const GATE_BUTTONS = [
  { id: 'H', title: 'Hadamard (Superposition)', accent: 'hover:border-cyan-400 hover:text-cyan-500 dark:hover:text-cyan-300' },
  { id: 'X', title: 'Pauli-X (Bit Flip)', accent: 'hover:border-blue-400 hover:text-blue-500 dark:hover:text-blue-300' },
  { id: 'Y', title: 'Pauli-Y (Bit + Phase)', accent: 'hover:border-indigo-400 hover:text-indigo-500 dark:hover:text-indigo-300' },
  { id: 'Z', title: 'Pauli-Z (Phase Flip)', accent: 'hover:border-violet-400 hover:text-violet-500 dark:hover:text-violet-300' },
  { id: 'T', title: 'T Gate (π/4 Phase)', accent: 'hover:border-teal-400 hover:text-teal-500 dark:hover:text-teal-300' },
];

export default function MiniBlochTeaser() {
  const [state, setState] = useState(INITIAL_STATE);
  const [history, setHistory] = useState([]);

  const metrics = useMemo(() => {
    const { alpha, beta } = state;
    const [ar, ai] = alpha;
    const [br, bi] = beta;

    const bx = 2 * (ar * br + ai * bi);
    const by = 2 * (ar * bi - ai * br);
    const bz = cAbs2(alpha) - cAbs2(beta);

    const p0 = Math.min(1, Math.max(0, cAbs2(alpha)));
    const p1 = Math.min(1, Math.max(0, cAbs2(beta)));

    const cx = 64;
    const cy = 64;
    const radius = 44;
    const px = cx + radius * (0.86 * by - 0.36 * bx);
    const py = cy - radius * bz + radius * (0.2 * bx + 0.14 * by);

    const phiDeg = ((Math.atan2(by, bx) * 180) / Math.PI + 360) % 360;
    const tipColor =
      Math.abs(bz) > 0.95
        ? bz > 0
          ? '#22d3ee'
          : '#a855f7'
        : `hsl(${Math.round(180 + (phiDeg / 360) * 110)}, 88%, 58%)`;

    const aStr = formatComplex(alpha);
    const bStr = formatComplex(beta);
    let ket = '|ψ⟩ = ';
    if (aStr !== '0' && bStr !== '0') {
      const bTerm = bStr.startsWith('-') ? `- ${bStr.slice(1)}|1⟩` : `+ ${bStr}|1⟩`;
      ket += `${aStr}|0⟩ ${bTerm}`;
    } else if (aStr !== '0') {
      ket += `${aStr}|0⟩`;
    } else {
      ket += `${bStr}|1⟩`;
    }

    return {
      bx,
      by,
      bz,
      p0,
      p1,
      px,
      py,
      tipColor,
      ket,
      label: classifyBlochState(bx, by, bz),
    };
  }, [state]);

  const handleGate = (gate) => {
    setState((prev) => applySingleQubitGate(prev, gate));
    setHistory((prev) => [...prev.slice(-5), gate]);
  };

  const handleReset = () => {
    setState(INITIAL_STATE);
    setHistory([]);
  };

  return (
    <div className="rounded-2xl border border-slate-300/70 dark:border-cyan-400/20 bg-white/70 dark:bg-[#0b1224]/75 backdrop-blur-xl p-4 sm:p-5 shadow-lg shadow-slate-900/5 dark:shadow-cyan-950/30">
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <div className="inline-flex items-center gap-2">
          <span className="inline-flex h-6 w-6 items-center justify-center rounded-lg bg-cyan-500/15 text-cyan-600 dark:text-cyan-300">
            <Sparkles className="h-3.5 w-3.5" />
          </span>
          <div>
            <div className="text-xs font-bold tracking-wide text-slate-900 dark:text-slate-100">
              Live Qubit Sandbox
            </div>
            <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
              {metrics.label}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5 font-mono text-[11px] text-slate-500 dark:text-slate-400">
          <span className="px-2 py-0.5 rounded-md bg-slate-200/70 dark:bg-slate-800/80 text-slate-700 dark:text-cyan-300">
            |0⟩{history.length > 0 ? ` → ${history.join(' → ')}` : ''}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-[128px_1fr] gap-4 items-center">
        {/* SVG Bloch Sphere Projection */}
        <div className="mx-auto sm:mx-0 flex items-center justify-center">
          <svg
            width="128"
            height="128"
            viewBox="0 0 128 128"
            role="img"
            aria-label={`Interactive Bloch sphere showing ${metrics.label}`}
            className="overflow-visible"
          >
            <defs>
              <radialGradient id="blochSphereFill" cx="38%" cy="32%" r="68%">
                <stop offset="0%" stopColor="rgba(56, 189, 248, 0.24)" />
                <stop offset="65%" stopColor="rgba(59, 130, 246, 0.08)" />
                <stop offset="100%" stopColor="rgba(15, 23, 42, 0.14)" />
              </radialGradient>
            </defs>

            {/* Outer sphere */}
            <circle
              cx="64"
              cy="64"
              r="44"
              fill="url(#blochSphereFill)"
              className="stroke-slate-400/50 dark:stroke-cyan-400/35"
              strokeWidth="1.25"
            />
            {/* Equator */}
            <ellipse
              cx="64"
              cy="64"
              rx="44"
              ry="13"
              fill="none"
              className="stroke-slate-400/45 dark:stroke-cyan-300/30"
              strokeDasharray="3 3"
              strokeWidth="1"
            />
            {/* Vertical Z axis */}
            <line
              x1="64"
              y1="16"
              x2="64"
              y2="112"
              className="stroke-slate-400/40 dark:stroke-slate-500/45"
              strokeWidth="1"
            />
            {/* Pole labels */}
            <text
              x="64"
              y="12"
              textAnchor="middle"
              className="fill-slate-600 dark:fill-cyan-300 text-[9px] font-mono font-semibold"
            >
              |0⟩
            </text>
            <text
              x="64"
              y="123"
              textAnchor="middle"
              className="fill-slate-600 dark:fill-violet-300 text-[9px] font-mono font-semibold"
            >
              |1⟩
            </text>

            {/* Live State Vector */}
            <line
              x1="64"
              y1="64"
              x2={metrics.px}
              y2={metrics.py}
              stroke={metrics.tipColor}
              strokeWidth="2.6"
              strokeLinecap="round"
            />
            <circle cx="64" cy="64" r="2.5" className="fill-slate-500 dark:fill-slate-300" />
            <circle cx={metrics.px} cy={metrics.py} r="7" fill={metrics.tipColor} opacity="0.24" />
            <circle cx={metrics.px} cy={metrics.py} r="4" fill={metrics.tipColor} />
          </svg>
        </div>

        {/* Controls + Readout */}
        <div className="space-y-3 min-w-0">
          <div className="rounded-xl border border-slate-200/80 dark:border-slate-700/70 bg-slate-100/80 dark:bg-[#060b18]/80 px-3 py-2 font-mono text-xs text-slate-800 dark:text-cyan-200 truncate">
            {metrics.ket}
          </div>

          {/* Probability Bars */}
          <div className="grid grid-cols-2 gap-2.5 text-[11px] font-mono">
            <div>
              <div className="flex justify-between text-slate-600 dark:text-slate-300 mb-1">
                <span>P(|0⟩)</span>
                <span>{Math.round(metrics.p0 * 100)}%</span>
              </div>
              <div className="h-1.5 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-300"
                  style={{ width: `${Math.round(metrics.p0 * 100)}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-slate-600 dark:text-slate-300 mb-1">
                <span>P(|1⟩)</span>
                <span>{Math.round(metrics.p1 * 100)}%</span>
              </div>
              <div className="h-1.5 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-300"
                  style={{ width: `${Math.round(metrics.p1 * 100)}%` }}
                />
              </div>
            </div>
          </div>

          {/* Interactive Gate Buttons */}
          <div className="flex flex-wrap items-center gap-1.5">
            {GATE_BUTTONS.map((g) => (
              <button
                key={g.id}
                type="button"
                title={g.title}
                onClick={() => handleGate(g.id)}
                className={`px-2.5 py-1.5 rounded-lg border border-slate-300/80 dark:border-slate-700 bg-white/80 dark:bg-slate-900/80 text-xs font-mono font-semibold text-slate-700 dark:text-slate-200 transition active:scale-95 ${g.accent}`}
              >
                {g.id}
              </button>
            ))}
            <button
              type="button"
              onClick={handleReset}
              title="Reset qubit to |0⟩"
              className="ml-auto inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-300/80 dark:border-slate-700 bg-slate-100/90 dark:bg-slate-800/70 text-[11px] font-medium text-slate-600 dark:text-slate-300 hover:border-cyan-400/60 hover:text-cyan-600 dark:hover:text-cyan-300 transition"
            >
              <RotateCcw className="h-3 w-3" />
              |0⟩
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
