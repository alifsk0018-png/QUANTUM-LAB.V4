import React, { useEffect, useRef } from 'react';

const PARTICLE_COUNT = 38;
const LINK_DISTANCE = 148;

function createParticles(width, height) {
  const particles = [];
  for (let i = 0; i < PARTICLE_COUNT; i += 1) {
    const angle = (i / PARTICLE_COUNT) * Math.PI * 2 + (i % 5) * 0.4;
    const speed = 0.18 + (i % 7) * 0.04;
    particles.push({
      x: ((i * 97) % Math.max(width, 320)) + (Math.random() * 40 - 20),
      y: ((i * 61) % Math.max(height, 240)) + (Math.random() * 40 - 20),
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      radius: 1.4 + (i % 3) * 0.75,
      phase: i * 0.55,
      tone: i % 3,
    });
  }
  return particles;
}

export default function QuantumFieldCanvas({ isDark }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return undefined;
    const ctx = canvas.getContext('2d');
    if (!ctx) return undefined;

    const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    let reducedMotion = motionQuery.matches;

    let width = window.innerWidth;
    let height = window.innerHeight;
    let dpr = Math.min(window.devicePixelRatio || 1, 2);
    let particles = createParticles(width, height);
    let pointer = { x: width * 0.5, y: height * 0.42, active: false };
    let rafId = null;
    let startTime = performance.now();

    const resize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      particles = particles.map((p) => ({
        ...p,
        x: Math.min(Math.max(p.x, 12), Math.max(width - 12, 24)),
        y: Math.min(Math.max(p.y, 12), Math.max(height - 12, 24)),
      }));
    };

    const handlePointerMove = (e) => {
      pointer = { x: e.clientX, y: e.clientY, active: true };
    };

    const handlePointerLeave = () => {
      pointer.active = false;
    };

    const handleMotionChange = (e) => {
      reducedMotion = e.matches;
      if (reducedMotion && rafId) {
        cancelAnimationFrame(rafId);
        rafId = null;
        drawFrame(performance.now());
      } else if (!reducedMotion && !rafId) {
        rafId = requestAnimationFrame(tick);
      }
    };

    const drawWaves = (t) => {
      const waveConfigs = isDark
        ? [
            { amp: 28, freq: 0.0042, speed: 0.0007, yRatio: 0.34, color: 'rgba(34, 211, 238, 0.14)' },
            { amp: 22, freq: 0.0056, speed: -0.00055, yRatio: 0.56, color: 'rgba(99, 102, 241, 0.14)' },
            { amp: 18, freq: 0.007, speed: 0.00045, yRatio: 0.74, color: 'rgba(45, 212, 191, 0.10)' },
          ]
        : [
            { amp: 26, freq: 0.0042, speed: 0.0006, yRatio: 0.34, color: 'rgba(14, 165, 233, 0.16)' },
            { amp: 20, freq: 0.0056, speed: -0.0005, yRatio: 0.56, color: 'rgba(99, 102, 241, 0.14)' },
            { amp: 16, freq: 0.007, speed: 0.0004, yRatio: 0.74, color: 'rgba(13, 148, 136, 0.11)' },
          ];

      waveConfigs.forEach((w, idx) => {
        ctx.beginPath();
        const baseY = height * w.yRatio;
        for (let x = 0; x <= width; x += 18) {
          const modulation = Math.sin(x * w.freq * 0.5 + t * 0.0003 + idx);
          const y = baseY + Math.sin(x * w.freq + t * w.speed + idx * 1.4) * w.amp * (0.75 + 0.25 * modulation);
          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.strokeStyle = w.color;
        ctx.lineWidth = 1.25;
        ctx.stroke();
      });
    };

    const drawFrame = (now) => {
      const elapsed = now - startTime;
      ctx.clearRect(0, 0, width, height);

      // Soft ambient prism orbs
      const orb1 = ctx.createRadialGradient(
        width * 0.18,
        height * 0.22,
        10,
        width * 0.18,
        height * 0.22,
        Math.max(width, height) * 0.42
      );
      if (isDark) {
        orb1.addColorStop(0, 'rgba(34, 211, 238, 0.14)');
        orb1.addColorStop(0.55, 'rgba(59, 130, 246, 0.05)');
        orb1.addColorStop(1, 'rgba(6, 9, 19, 0)');
      } else {
        orb1.addColorStop(0, 'rgba(14, 165, 233, 0.14)');
        orb1.addColorStop(0.55, 'rgba(99, 102, 241, 0.06)');
        orb1.addColorStop(1, 'rgba(241, 245, 249, 0)');
      }
      ctx.fillStyle = orb1;
      ctx.fillRect(0, 0, width, height);

      const orb2 = ctx.createRadialGradient(
        width * 0.82,
        height * 0.72,
        10,
        width * 0.82,
        height * 0.72,
        Math.max(width, height) * 0.4
      );
      if (isDark) {
        orb2.addColorStop(0, 'rgba(168, 85, 247, 0.14)');
        orb2.addColorStop(0.5, 'rgba(45, 212, 191, 0.04)');
        orb2.addColorStop(1, 'rgba(6, 9, 19, 0)');
      } else {
        orb2.addColorStop(0, 'rgba(124, 58, 237, 0.10)');
        orb2.addColorStop(0.5, 'rgba(13, 148, 136, 0.05)');
        orb2.addColorStop(1, 'rgba(241, 245, 249, 0)');
      }
      ctx.fillStyle = orb2;
      ctx.fillRect(0, 0, width, height);

      drawWaves(elapsed);

      // Update & draw entangled qubit particles
      const nodeColors = isDark
        ? ['rgba(34, 211, 238, 0.75)', 'rgba(45, 212, 191, 0.75)', 'rgba(167, 139, 250, 0.75)']
        : ['rgba(2, 132, 199, 0.65)', 'rgba(13, 148, 136, 0.65)', 'rgba(109, 40, 217, 0.6)'];

      if (!reducedMotion) {
        for (let i = 0; i < particles.length; i += 1) {
          const p = particles[i];
          if (pointer.active) {
            const dx = pointer.x - p.x;
            const dy = pointer.y - p.y;
            const distSq = dx * dx + dy * dy;
            if (distSq > 16 && distSq < 44000) {
              const force = 0.00018;
              p.vx += dx * force;
              p.vy += dy * force;
            }
          }

          // Clamp velocity smoothly
          const speed = Math.hypot(p.vx, p.vy);
          if (speed > 0.72) {
            p.vx = (p.vx / speed) * 0.72;
            p.vy = (p.vy / speed) * 0.72;
          }

          p.x += p.vx;
          p.y += p.vy;

          if (p.x < 0 || p.x > width) p.vx *= -1;
          if (p.y < 0 || p.y > height) p.vy *= -1;
          p.x = Math.min(Math.max(p.x, 0), width);
          p.y = Math.min(Math.max(p.y, 0), height);
        }
      }

      // Draw entanglement filaments
      for (let i = 0; i < particles.length; i += 1) {
        const a = particles[i];
        for (let j = i + 1; j < particles.length; j += 1) {
          const b = particles[j];
          const dist = Math.hypot(a.x - b.x, a.y - b.y);
          if (dist < LINK_DISTANCE) {
            const alpha = (1 - dist / LINK_DISTANCE) * (isDark ? 0.24 : 0.18);
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.strokeStyle = isDark
              ? `rgba(56, 189, 248, ${alpha.toFixed(3)})`
              : `rgba(37, 99, 235, ${alpha.toFixed(3)})`;
            ctx.lineWidth = 0.9;
            ctx.stroke();
          }
        }
      }

      // Draw particles
      for (let i = 0; i < particles.length; i += 1) {
        const p = particles[i];
        const pulse = 0.75 + 0.25 * Math.sin(elapsed * 0.002 + p.phase);
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius * pulse, 0, Math.PI * 2);
        ctx.fillStyle = nodeColors[p.tone];
        ctx.fill();
      }
    };

    const tick = (now) => {
      drawFrame(now);
      if (!reducedMotion) {
        rafId = requestAnimationFrame(tick);
      }
    };

    resize();
    window.addEventListener('resize', resize);
    window.addEventListener('pointermove', handlePointerMove, { passive: true });
    window.addEventListener('pointerleave', handlePointerLeave);
    motionQuery.addEventListener?.('change', handleMotionChange);

    if (reducedMotion) {
      drawFrame(performance.now());
    } else {
      rafId = requestAnimationFrame(tick);
    }

    return () => {
      if (rafId) cancelAnimationFrame(rafId);
      window.removeEventListener('resize', resize);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerleave', handlePointerLeave);
      motionQuery.removeEventListener?.('change', handleMotionChange);
    };
  }, [isDark]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-0"
    />
  );
}
