import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

let authToken = null;

export function setAuthToken(token) {
  authToken = token || null;
}

api.interceptors.request.use((config) => {
  if (authToken) {
    config.headers = config.headers || {};
    config.headers.Authorization = `Bearer ${authToken}`;
  }
  return config;
});

export function extractApiError(err, fallback = 'Request failed. Please check backend connection.') {
  if (err?.response?.data?.detail) {
    const detail = err.response.data.detail;
    if (typeof detail === 'string') return detail;
    if (Array.isArray(detail)) {
      return detail.map((d) => d.msg || JSON.stringify(d)).join('; ');
    }
  }
  if (err?.message) return err.message;
  return fallback;
}

export async function checkHealth() {
  const { data } = await api.get('/api/health');
  return data;
}

export async function getDashboardSummary() {
  const { data } = await api.get('/api/dashboard/summary');
  return data;
}

export async function getGates() {
  const { data } = await api.get('/api/gates');
  return data;
}

export async function validateCircuit(circuitConfig) {
  const { data } = await api.post('/api/circuit/validate', circuitConfig);
  return data;
}

export async function runSimulation(simulationRequest) {
  const { data } = await api.post('/api/simulate', simulationRequest);
  return data;
}

export async function getExperiments(skip = 0, limit = 100) {
  const { data } = await api.get('/api/experiments', { params: { skip, limit } });
  return data;
}

export async function getExperiment(id) {
  const { data } = await api.get(`/api/experiments/${id}`);
  return data;
}

export async function createExperiment(payload) {
  const { data } = await api.post('/api/experiments', payload);
  return data;
}

export async function updateExperiment(id, payload) {
  const { data } = await api.put(`/api/experiments/${id}`, payload);
  return data;
}

export async function deleteExperiment(id) {
  const { data } = await api.delete(`/api/experiments/${id}`);
  return data;
}

export async function getExperimentStats() {
  const { data } = await api.get('/api/experiments/stats');
  return data;
}

export async function getLearningModules() {
  const { data } = await api.get('/api/learning');
  return data;
}

export async function getLearningProgress() {
  const { data } = await api.get('/api/learning/progress');
  return data;
}

export async function visitLesson(moduleId, lessonId) {
  const { data } = await api.post(`/api/learning/${moduleId}/lessons/${lessonId}/visit`);
  return data;
}

export async function submitQuiz(payload) {
  const { data } = await api.post('/api/quiz/submit', payload);
  return data;
}

export async function explainWithTutor(payload) {
  const { data } = await api.post('/api/tutor/explain', payload);
  return data;
}

export async function chatWithTutor(payload) {
  const { data } = await api.post('/api/tutor/chat', payload);
  return data;
}

/** Offline speech-to-text: upload a recorded voice question, get text back. */
export async function transcribeAudio(blob, language = 'en') {
  const ext = blob.type.includes('ogg') ? 'ogg' : blob.type.includes('mp4') ? 'm4a' : blob.type.includes('wav') ? 'wav' : 'webm';
  const form = new FormData();
  form.append('audio', blob, `question.${ext}`);
  form.append('language', language);
  const { data } = await api.post('/api/tutor/transcribe', form, {
    headers: { 'Content-Type': 'multipart/form-data' },
    timeout: 180000, // first use may download the speech model
  });
  return data;
}

export async function getVoiceStatus() {
  const { data } = await api.get('/api/tutor/voice/status');
  return data;
}

export async function saveAIConfig(payload) {
  const { data } = await api.post('/api/tutor/config', payload);
  return data;
}

export async function registerUser(payload) {
  const { data } = await api.post('/api/auth/register', payload);
  return data;
}

export async function loginUser(payload) {
  const { data } = await api.post('/api/auth/login', payload);
  return data;
}

export async function loginDemoUser() {
  const { data } = await api.post('/api/auth/demo');
  return data;
}

export async function fetchCurrentUser() {
  const { data } = await api.get('/api/auth/me');
  return data;
}

export async function updateAuthProfile(payload) {
  const { data } = await api.put('/api/auth/profile', payload);
  return data;
}

export async function logoutUser() {
  const { data } = await api.post('/api/auth/logout');
  return data;
}

export default api;
