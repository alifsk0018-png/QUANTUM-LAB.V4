/**
 * Main-thread client for the in-browser Whisper worker.
 * Decodes recorded audio to 16 kHz mono PCM and asks the worker to transcribe it.
 */

let worker = null;
let nextId = 1;
const pending = new Map();
const progressListeners = new Set();
let readyPromise = null;
let modelReady = false;

function getWorker() {
  if (!worker) {
    worker = new Worker(new URL('../workers/whisperWorker.js', import.meta.url), { type: 'module' });
    worker.addEventListener('message', (event) => {
      const msg = event.data || {};
      if (msg.type === 'progress') {
        progressListeners.forEach((fn) => fn(msg));
        return;
      }
      if (msg.type === 'ready' || (msg.type === 'error' && msg.id === undefined)) {
        const p = pending.get('load');
        if (p) {
          pending.delete('load');
          if (msg.type === 'ready') {
            modelReady = true;
            p.resolve();
          } else {
            p.reject(new Error(msg.message));
          }
        }
        return;
      }
      const p = pending.get(msg.id);
      if (!p) return;
      pending.delete(msg.id);
      if (msg.type === 'result') {
        modelReady = true;
        p.resolve(msg.text);
      } else {
        p.reject(new Error(msg.message || 'Transcription failed.'));
      }
    });
    worker.addEventListener('error', (e) => {
      const err = new Error(e.message || 'Speech engine crashed.');
      pending.forEach((p) => p.reject(err));
      pending.clear();
      worker = null;
      readyPromise = null;
      modelReady = false;
    });
  }
  return worker;
}

export function isSpeechModelReady() {
  return modelReady;
}

/** Start downloading / initialising the speech model in the background. */
export function preloadSpeechModel() {
  if (!readyPromise) {
    readyPromise = new Promise((resolve, reject) => {
      pending.set('load', { resolve, reject });
      getWorker().postMessage({ type: 'load' });
    }).catch((err) => {
      readyPromise = null;
      modelReady = false;
      throw err;
    });
  }
  return readyPromise;
}

export function onSpeechModelProgress(fn) {
  progressListeners.add(fn);
  return () => progressListeners.delete(fn);
}

async function blobToPcm16k(blob) {
  const arrayBuffer = await blob.arrayBuffer();
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  const ctx = new AudioCtx();
  let decoded;
  try {
    decoded = await ctx.decodeAudioData(arrayBuffer);
  } finally {
    ctx.close().catch(() => {});
  }
  // Mix down to mono and resample to 16 kHz with an OfflineAudioContext.
  const targetRate = 16000;
  const length = Math.max(1, Math.ceil(decoded.duration * targetRate));
  const offline = new OfflineAudioContext(1, length, targetRate);
  const src = offline.createBufferSource();
  src.buffer = decoded;
  src.connect(offline.destination);
  src.start();
  const rendered = await offline.startRendering();
  return rendered.getChannelData(0);
}

/** Transcribe a recorded audio Blob to text entirely inside the browser. */
export async function transcribeInBrowser(blob) {
  const audio = await blobToPcm16k(blob);
  await preloadSpeechModel();
  const id = nextId++;
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
    getWorker().postMessage({ type: 'transcribe', id, audio }, [audio.buffer]);
  });
}
