import { useCallback, useEffect, useRef, useState } from 'react';
import { transcribeAudio, extractApiError } from '../services/api';
import {
  transcribeInBrowser,
  onSpeechModelProgress,
} from '../services/speechToText';

/**
 * Voice I/O for Q-ASSIST.
 *
 * Speech-to-text uses two engines:
 *  1. "browser" – Web Speech SpeechRecognition (live captions; Chrome / Edge).
 *     It relies on an online cloud service that many embedded browsers lack.
 *  2. "offline" – records the mic with MediaRecorder and transcribes it on the
 *     QUANTUM LAB backend with Whisper. Works in any browser with a microphone.
 * If the browser engine is missing or fails, we switch to "offline" automatically.
 *
 * Text-to-speech uses speechSynthesis, preferring local (on-device) voices.
 */

const ENGINE_KEY = 'qlab_voice_engine';

const getRecognitionCtor = () =>
  typeof window !== 'undefined'
    ? window.SpeechRecognition || window.webkitSpeechRecognition || null
    : null;

const recorderSupported = () =>
  typeof window !== 'undefined' &&
  typeof window.MediaRecorder !== 'undefined' &&
  Boolean(navigator.mediaDevices?.getUserMedia);

function pickRecorderMime() {
  const candidates = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'];
  return candidates.find((t) => window.MediaRecorder.isTypeSupported?.(t)) || '';
}

/** Convert markdown / quantum notation into something pleasant to hear. */
export function toSpeakableText(markdown = '') {
  return markdown
    .replace(/```[\s\S]*?```/g, ' (code example shown on screen) ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/\$\$[\s\S]*?\$\$/g, ' (equation shown on screen) ')
    .replace(/\$([^$]+)\$/g, '$1')
    .replace(/!\[[^\]]*\]\([^)]*\)/g, '')
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
    .replace(/\|([^|⟩>\s]{1,8})[⟩>]/g, ' ket $1 ')
    .replace(/[⟨<]([^|⟨<\s]{1,8})\|/g, ' bra $1 ')
    .replace(/√/g, ' square root of ')
    .replace(/ψ/g, ' psi ')
    .replace(/φ/g, ' phi ')
    .replace(/θ/g, ' theta ')
    .replace(/π/g, ' pi ')
    .replace(/⊗/g, ' tensor ')
    .replace(/→/g, ' becomes ')
    .replace(/^\s{0,3}#{1,6}\s+/gm, '')
    .replace(/^\s*[-*+]\s+/gm, '')
    .replace(/^\s*>\s?/gm, '')
    .replace(/\|/g, ' ')
    .replace(/[*_~#]+/g, '')
    .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}]/gu, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Chrome stops long utterances after ~15s, so speak sentence-sized chunks. */
function chunkText(text, maxLen = 220) {
  const sentences = text.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || [text];
  const chunks = [];
  let current = '';
  for (const s of sentences) {
    if ((current + s).length > maxLen && current) {
      chunks.push(current.trim());
      current = '';
    }
    if (s.length > maxLen) {
      const parts = s.match(new RegExp(`.{1,${maxLen}}(\\s|,|$)`, 'g')) || [s];
      chunks.push(...parts.map((p) => p.trim()).filter(Boolean));
    } else {
      current += s;
    }
  }
  if (current.trim()) chunks.push(current.trim());
  return chunks;
}

function pickVoice(voices, lang) {
  const base = lang.split('-')[0];
  const sameLang = voices.filter((v) => v.lang?.toLowerCase().startsWith(base));
  // Local voices work offline and inside embedded browsers; prefer them.
  const local = sameLang.filter((v) => v.localService);
  return (
    local.find((v) => v.lang === lang) ||
    local[0] ||
    sameLang.find((v) => v.lang === lang) ||
    sameLang[0] ||
    voices.find((v) => v.default) ||
    null
  );
}

export default function useVoice({ lang = 'en-US', onFinalTranscript } = {}) {
  const RecognitionCtor = getRecognitionCtor();
  const canRecord = recorderSupported();
  const synthesisSupported = typeof window !== 'undefined' && 'speechSynthesis' in window;

  const [engine, setEngine] = useState(() => {
    if (!RecognitionCtor) return 'offline';
    try {
      return localStorage.getItem(ENGINE_KEY) === 'offline' ? 'offline' : 'browser';
    } catch {
      return 'browser';
    }
  });
  const recognitionSupported = Boolean(RecognitionCtor) || canRecord;

  const [listening, setListening] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const [modelProgress, setModelProgress] = useState(null);
  const [interimTranscript, setInterimTranscript] = useState('');
  const [level, setLevel] = useState(0);
  const [speakingId, setSpeakingId] = useState(null);
  const [voiceError, setVoiceError] = useState(null);
  const [voiceNotice, setVoiceNotice] = useState(null);

  const recognitionRef = useRef(null);
  const finalTextRef = useRef('');
  const recorderRef = useRef(null);
  const audioCleanupRef = useRef(null);
  const voicesRef = useRef([]);
  const speakTokenRef = useRef(0);
  const onFinalRef = useRef(onFinalTranscript);
  onFinalRef.current = onFinalTranscript;

  // Subscribe to in-browser Whisper download/init progress when fallback runs.
  useEffect(() => {
    return onSpeechModelProgress((p) => {
      if (typeof p?.progress === 'number') {
        setModelProgress(Math.round(p.progress));
      }
    });
  }, []);

  // Load available TTS voices (they arrive asynchronously in Chrome).
  useEffect(() => {
    if (!synthesisSupported) return undefined;
    const load = () => {
      voicesRef.current = window.speechSynthesis.getVoices();
    };
    load();
    window.speechSynthesis.addEventListener('voiceschanged', load);
    return () => {
      window.speechSynthesis.removeEventListener('voiceschanged', load);
      window.speechSynthesis.cancel();
    };
  }, [synthesisSupported]);

  // ---------- Text-to-speech ----------
  const stopSpeaking = useCallback(() => {
    if (!synthesisSupported) return;
    speakTokenRef.current += 1;
    window.speechSynthesis.cancel();
    setSpeakingId(null);
  }, [synthesisSupported]);

  const speak = useCallback(
    (markdown, id = 'speech') => {
      if (!synthesisSupported) return;
      const text = toSpeakableText(markdown);
      if (!text) return;

      window.speechSynthesis.cancel();
      const token = ++speakTokenRef.current;
      const voice = pickVoice(voicesRef.current, lang);
      const chunks = chunkText(text);
      setSpeakingId(id);

      chunks.forEach((chunk, i) => {
        const u = new SpeechSynthesisUtterance(chunk);
        u.lang = voice?.lang || lang;
        if (voice) u.voice = voice;
        u.rate = 1;
        u.pitch = 1;
        const finish = () => {
          if (speakTokenRef.current === token && i === chunks.length - 1) setSpeakingId(null);
        };
        u.onend = finish;
        u.onerror = finish;
        window.speechSynthesis.speak(u);
      });
    },
    [lang, synthesisSupported]
  );

  // ---------- Speech-to-text: offline recorder engine ----------
  const deliverText = useCallback((text) => {
    const clean = (text || '').trim();
    if (clean) onFinalRef.current?.(clean);
    else setVoiceError("I didn't catch that. Tap the mic and try again.");
  }, []);

  const stopRecorder = useCallback(() => {
    const rec = recorderRef.current;
    if (rec && rec.state !== 'inactive') rec.stop();
  }, []);

  const startRecorder = useCallback(async () => {
    if (!canRecord) {
      setVoiceError('This browser cannot record audio for voice questions.');
      return;
    }
    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      });
    } catch (err) {
      const name = err?.name || '';
      setVoiceError(
        name === 'NotAllowedError' || name === 'SecurityError'
          ? 'Microphone access was blocked. Allow mic permission for this site and try again.'
          : name === 'NotFoundError'
          ? 'No microphone was found on this device.'
          : `Could not open the microphone (${name || err?.message || 'unknown error'}).`
      );
      return;
    }

    const mimeType = pickRecorderMime();
    const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
    const chunks = [];
    recorderRef.current = recorder;

    // Simple voice-activity detection: auto-stop after the user stops talking.
    let ctx = null;
    let raf = 0;
    let maxTimer = 0;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      ctx = new AudioCtx();
      if (ctx.state === 'suspended') ctx.resume().catch(() => {});
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 1024;
      source.connect(analyser);
      const buf = new Float32Array(analyser.fftSize);
      const startedAt = performance.now();
      let noiseFloor = 0.008;
      let heardSpeech = false;
      let lastVoiceAt = startedAt;

      const tick = () => {
        analyser.getFloatTimeDomainData(buf);
        let sum = 0;
        for (let i = 0; i < buf.length; i += 1) sum += buf[i] * buf[i];
        const rms = Math.sqrt(sum / buf.length);
        const now = performance.now();
        if (now - startedAt < 250) noiseFloor = Math.min(0.02, Math.max(noiseFloor, rms));
        const threshold = Math.max(0.015, Math.min(0.035, noiseFloor * 1.8));
        setLevel(Math.round(Math.min(1, rms / 0.15) * 10) / 10);

        if (rms > threshold) {
          heardSpeech = true;
          lastVoiceAt = now;
        }
        const silentFor = now - lastVoiceAt;
        if (
          (heardSpeech && silentFor > 2200 && now - startedAt > 1200) ||
          (!heardSpeech && now - startedAt > 10000)
        ) {
          stopRecorder();
          return;
        }
        raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    } catch {
      /* VAD is optional; user can tap the mic to stop. */
    }
    maxTimer = window.setTimeout(stopRecorder, 30000);

    const cleanup = () => {
      cancelAnimationFrame(raf);
      window.clearTimeout(maxTimer);
      stream.getTracks().forEach((t) => t.stop());
      ctx?.close().catch(() => {});
      setLevel(0);
    };
    audioCleanupRef.current = cleanup;

    recorder.ondataavailable = (e) => {
      if (e.data && e.data.size) chunks.push(e.data);
    };
    recorder.onstop = async () => {
      cleanup();
      audioCleanupRef.current = null;
      recorderRef.current = null;
      setListening(false);
      const blob = new Blob(chunks, { type: recorder.mimeType || mimeType || 'audio/webm' });
      if (blob.size < 400) {
        setVoiceError("I didn't catch that. Tap the mic and try again.");
        return;
      }
      setTranscribing(true);
      try {
        let text = '';
        let backendErr = null;
        try {
          const res = await transcribeAudio(blob, lang);
          text = (res?.text || '').trim();
        } catch (err) {
          backendErr = err;
        }
        if (!text) {
          try {
            text = await transcribeInBrowser(blob);
          } catch (browserErr) {
            if (backendErr) throw backendErr;
            throw browserErr;
          }
        }
        deliverText(text);
      } catch (err) {
        setVoiceError(extractApiError(err, 'Voice transcription failed.'));
      } finally {
        setTranscribing(false);
        setModelProgress(null);
      }
    };

    recorder.start(250);
    setListening(true);
  }, [canRecord, deliverText, lang, stopRecorder]);

  // ---------- Speech-to-text: browser (Web Speech) engine ----------
  const switchToOffline = useCallback(
    (autoStart) => {
      setEngine('offline');
      try {
        localStorage.setItem(ENGINE_KEY, 'offline');
      } catch {
        /* ignore */
      }
      setVoiceNotice('Switched to the offline voice engine — speak your question now.');
      if (autoStart) startRecorder();
    },
    [startRecorder]
  );

  const startBrowserRecognition = useCallback(() => {
    finalTextRef.current = '';
    setInterimTranscript('');
    let fellBack = false;

    const rec = new RecognitionCtor();
    rec.lang = lang;
    rec.interimResults = true;
    rec.continuous = false;
    rec.maxAlternatives = 1;

    rec.onstart = () => setListening(true);
    rec.onresult = (event) => {
      let interim = '';
      for (let i = event.resultIndex; i < event.results.length; i += 1) {
        const r = event.results[i];
        if (r.isFinal) finalTextRef.current += r[0].transcript;
        else interim += r[0].transcript;
      }
      setInterimTranscript((finalTextRef.current + interim).trim());
    };
    rec.onerror = (event) => {
      if (['network', 'service-not-allowed', 'language-not-supported'].includes(event.error) && canRecord) {
        fellBack = true; // cloud speech service unavailable here
        return;
      }
      const messages = {
        'not-allowed': 'Microphone access was blocked. Allow mic permission in your browser.',
        'no-speech': "I didn't hear anything. Tap the mic and try again.",
        'audio-capture': 'No microphone was found on this device.',
        network: 'Speech recognition needs an internet connection.',
      };
      if (event.error !== 'aborted') {
        setVoiceError(messages[event.error] || `Voice input error: ${event.error}`);
      }
    };
    rec.onend = () => {
      setListening(false);
      recognitionRef.current = null;
      const finalText = finalTextRef.current.trim();
      setInterimTranscript('');
      if (fellBack) switchToOffline(true);
      else if (finalText) onFinalRef.current?.(finalText);
    };

    recognitionRef.current = rec;
    try {
      rec.start();
    } catch {
      recognitionRef.current = null;
      if (canRecord) switchToOffline(true);
      else setVoiceError('Could not start the microphone. Please try again.');
    }
  }, [RecognitionCtor, canRecord, lang, switchToOffline]);

  // ---------- Public controls ----------
  const startListening = useCallback(() => {
    if (listening || transcribing) return;
    stopSpeaking(); // don't let the assistant hear itself
    setVoiceError(null);
    if (engine === 'browser' && RecognitionCtor) startBrowserRecognition();
    else startRecorder();
  }, [RecognitionCtor, engine, listening, startBrowserRecognition, startRecorder, stopSpeaking, transcribing]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current) recognitionRef.current.stop();
    else stopRecorder();
  }, [stopRecorder]);

  useEffect(
    () => () => {
      recognitionRef.current?.abort();
      const rec = recorderRef.current;
      if (rec && rec.state !== 'inactive') {
        rec.onstop = null;
        rec.stop();
      }
      audioCleanupRef.current?.();
    },
    []
  );

  return {
    engine,
    recognitionSupported,
    synthesisSupported,
    listening,
    transcribing,
    modelProgress,
    interimTranscript,
    level,
    startListening,
    stopListening,
    speak,
    stopSpeaking,
    speakingId,
    voiceError,
    clearVoiceError: () => setVoiceError(null),
    voiceNotice,
    clearVoiceNotice: () => setVoiceNotice(null),
  };
}
