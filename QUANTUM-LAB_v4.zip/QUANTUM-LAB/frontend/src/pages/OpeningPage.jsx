import React, { useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  AlertCircle,
  ArrowRight,
  Atom,
  Bot,
  CheckCircle2,
  Cpu,
  Eye,
  EyeOff,
  KeyRound,
  LogOut,
  Moon,
  Orbit,
  ShieldCheck,
  Sparkles,
  Sun,
  UserCheck,
  UserPlus,
} from 'lucide-react';
import toast from 'react-hot-toast';
import QuantumLogo from '../components/ui/QuantumLogo';
import QuantumFieldCanvas from '../components/opening/QuantumFieldCanvas';
import MiniBlochTeaser from '../components/opening/MiniBlochTeaser';
import { useAuth } from '../context/AuthContext';
import { useQuantum } from '../context/QuantumContext';
import { useTheme } from '../context/ThemeContext';
import { extractApiError } from '../services/api';

const CAPABILITY_TILES = [
  {
    icon: Cpu,
    title: 'IBM Qiskit Engine',
    detail: 'Exact Statevector & noisy Aer simulations up to 8 qubits',
    accent: 'text-cyan-600 dark:text-cyan-300 bg-cyan-500/10 border-cyan-500/25',
  },
  {
    icon: Orbit,
    title: '3D State Optics',
    detail: 'Interactive Bloch sphere, Q-Sphere & phase amplitudes',
    accent: 'text-indigo-600 dark:text-indigo-300 bg-indigo-500/10 border-indigo-500/25',
  },
  {
    icon: Bot,
    title: 'Q-ASSIST AI Tutor',
    detail: 'Circuit debugging, Dirac math & guided quantum academy',
    accent: 'text-teal-600 dark:text-teal-300 bg-teal-500/10 border-teal-500/25',
  },
];

function computePasswordStrength(password) {
  if (!password) return { score: 0, label: '', color: 'bg-slate-300 dark:bg-slate-700' };
  let score = 0;
  if (password.length >= 6) score += 1;
  if (password.length >= 10) score += 1;
  if ((/[a-z]/.test(password) && /[A-Z]/.test(password)) || /\d/.test(password)) score += 1;
  if (/[^A-Za-z0-9]/.test(password) && password.length >= 8) score += 1;

  if (score <= 1) return { score: 1, label: 'Weak', color: 'bg-rose-500' };
  if (score === 2) return { score: 2, label: 'Fair', color: 'bg-amber-500' };
  if (score === 3) return { score: 3, label: 'Good', color: 'bg-cyan-500' };
  return { score: 4, label: 'Strong', color: 'bg-emerald-500' };
}

function getInitials(name) {
  const parts = (name || 'QL').trim().split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export default function OpeningPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { isDark, toggleTheme, profile } = useTheme();
  const { backendHealth } = useQuantum();
  const {
    user,
    isAuthenticated,
    isGuest,
    isOfflineDemo,
    signIn,
    signUp,
    signInDemo,
    enterAsGuest,
    signOut,
  } = useAuth();

  const fromPath = location.state?.from?.pathname;
  const targetPath =
    fromPath && fromPath !== '/' && fromPath !== '/login' ? fromPath : '/dashboard';

  const [activeTab, setActiveTab] = useState('signin');
  const [showSwitchForm, setShowSwitchForm] = useState(false);

  // Sign In state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [showDemoHint, setShowDemoHint] = useState(false);

  // Register state
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regRole, setRegRole] = useState('Student');
  const [regInstitution, setRegInstitution] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirm, setRegConfirm] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);

  const [submitting, setSubmitting] = useState(false);
  const [demoLoading, setDemoLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const passwordStrength = useMemo(() => computePasswordStrength(regPassword), [regPassword]);
  const passwordsMismatch = regConfirm.length > 0 && regPassword !== regConfirm;

  const activeDisplayName = user?.name || profile.name || 'Guest Researcher';
  const activeRole = user?.role || profile.role || 'Student';

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    setErrorMsg('');
  };

  const handleSignInSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg('');
    if (!loginEmail.trim() || !loginPassword) {
      setErrorMsg('Please enter both your email address and password.');
      return;
    }

    setSubmitting(true);
    try {
      const signedInUser = await signIn({
        email: loginEmail.trim(),
        password: loginPassword,
        remember: rememberMe,
      });
      toast.success(`Welcome back, ${signedInUser.name}`);
      navigate(targetPath, { replace: true });
    } catch (err) {
      if (!err?.response) {
        setErrorMsg(
          'Backend API is offline. Start FastAPI or use Demo Researcher / Guest Lab Pass below.'
        );
      } else {
        setErrorMsg(extractApiError(err, 'Invalid email or password.'));
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleRegisterSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg('');

    if (regName.trim().length < 2) {
      setErrorMsg('Full name must be at least 2 characters.');
      return;
    }
    if (!regEmail.trim()) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }
    if (regPassword.length < 6) {
      setErrorMsg('Password must be at least 6 characters.');
      return;
    }
    if (regPassword !== regConfirm) {
      setErrorMsg('Passwords do not match.');
      return;
    }

    setSubmitting(true);
    try {
      const createdUser = await signUp({
        name: regName.trim(),
        email: regEmail.trim(),
        password: regPassword,
        role: regRole,
        institution: regInstitution.trim() || 'Quantum Lab Workspace',
        remember: rememberMe,
      });
      toast.success(`Account created! Welcome, ${createdUser.name}`);
      navigate(targetPath, { replace: true });
    } catch (err) {
      if (!err?.response) {
        setErrorMsg(
          'Backend API is unreachable to register new accounts. Use Guest Lab Pass or Demo Researcher below.'
        );
      } else {
        setErrorMsg(extractApiError(err, 'Could not create account.'));
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleDemoAccess = async () => {
    setErrorMsg('');
    setDemoLoading(true);
    try {
      const { user: demoUser, offline } = await signInDemo({ remember: rememberMe });
      toast.success(
        offline
          ? `Entered local demo mode as ${demoUser.name}`
          : `Signed in as ${demoUser.name}`
      );
      navigate(targetPath, { replace: true });
    } catch (err) {
      setErrorMsg(extractApiError(err, 'Unable to launch demo session.'));
    } finally {
      setDemoLoading(false);
    }
  };

  const handleGuestPass = () => {
    enterAsGuest();
    toast.success('Entered Quantum Lab in Local Guest Mode');
    navigate(targetPath, { replace: true });
  };

  const handleAutofillDemo = () => {
    setLoginEmail('ada@quantumlab.io');
    setLoginPassword('Quantum2026!');
    setErrorMsg('');
  };

  const handleSignOut = () => {
    signOut();
    setShowSwitchForm(false);
    setErrorMsg('');
    toast.success('Signed out of Quantum Lab');
  };

  return (
    <div className="min-h-screen relative overflow-x-hidden flex flex-col bg-[#f4f7fb] dark:bg-[#050814] text-slate-900 dark:text-slate-100 transition-colors duration-300">
      {/* Interactive Quantum Field Canvas & Observatory Grid */}
      <QuantumFieldCanvas isDark={isDark} />
      <div className="observatory-grid pointer-events-none fixed inset-0 z-0" aria-hidden="true" />

      {/* Top Floating Rail */}
      <header className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 sm:pt-6 pb-2 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <QuantumLogo size={36} />
          <span className="hidden sm:inline-flex items-center gap-1 rounded-full border border-cyan-500/30 bg-cyan-500/10 px-2.5 py-0.5 text-[10px] font-mono font-semibold tracking-wider text-cyan-700 dark:text-cyan-300">
            OBSERVATORY v2.0
          </span>
        </div>

        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Live Engine Telemetry Pill */}
          <div
            className="hidden md:inline-flex items-center gap-2 rounded-full border border-slate-300/80 dark:border-slate-700/80 bg-white/75 dark:bg-[#0b1224]/75 backdrop-blur-md px-3 py-1.5 text-xs font-mono text-slate-700 dark:text-slate-300"
            title="Backend Qiskit Simulation Engine Status"
          >
            <span
              className={`h-2 w-2 rounded-full ${
                backendHealth?.online ? 'bg-emerald-500 animate-pulse' : 'bg-amber-400'
              }`}
            />
            {backendHealth?.online
              ? `Qiskit ${backendHealth.qiskit_version || 'Ready'}`
              : 'Local Sandbox Mode'}
          </div>

          {/* Theme Toggle */}
          <button
            type="button"
            onClick={toggleTheme}
            aria-label={`Switch to ${isDark ? 'light' : 'dark'} theme`}
            title={`Switch to ${isDark ? 'light' : 'dark'} theme`}
            className="inline-flex items-center justify-center rounded-xl border border-slate-300/80 dark:border-slate-700/80 bg-white/80 dark:bg-[#0b1224]/80 backdrop-blur-md p-2.5 text-slate-700 dark:text-slate-200 hover:border-cyan-500/60 hover:text-cyan-600 dark:hover:text-cyan-300 transition"
          >
            {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>

          {/* Top Quick Guest Pass (when signed out) */}
          {!isAuthenticated && (
            <button
              type="button"
              onClick={handleGuestPass}
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300/80 dark:border-cyan-400/30 bg-white/80 dark:bg-cyan-500/10 backdrop-blur-md px-3 py-2 text-xs font-semibold text-slate-800 dark:text-cyan-300 hover:border-cyan-500 dark:hover:bg-cyan-500/20 transition"
            >
              <span>Guest Pass</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </header>

      {/* Main 12-Column Asymmetric Observatory Stage */}
      <main className="relative z-10 flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 sm:py-8 lg:py-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center">
        {/* Left Showcase Column (7 cols) */}
        <section className="lg:col-span-7 space-y-6">
          <div className="space-y-4">
            <div className="inline-flex items-center gap-2 rounded-full border border-cyan-500/35 bg-cyan-500/10 px-3.5 py-1 text-[11px] font-mono font-semibold tracking-wider text-cyan-700 dark:text-cyan-300">
              <Atom className="h-3.5 w-3.5" />
              QUANTUM OBSERVATORY · INTERACTIVE LAB
            </div>

            <h1 className="font-display text-4xl sm:text-5xl xl:text-[3.4rem] font-bold tracking-tight leading-[1.08] text-slate-950 dark:text-white">
              Enter the <span className="aurora-text">Quantum</span> Observatory.
            </h1>

            <p className="max-w-2xl text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
              Design multi-qubit circuits, execute genuine IBM Qiskit statevector &amp; noisy Aer
              simulations, explore 3D Bloch &amp; Q-Sphere optics, and master quantum algorithms with{' '}
              <span className="font-semibold text-slate-900 dark:text-cyan-300">Q-ASSIST</span>.
            </p>
          </div>

          {/* Interactive Live Qubit Sandbox */}
          <MiniBlochTeaser />

          {/* Capability Strip */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {CAPABILITY_TILES.map((tile) => {
              const Icon = tile.icon;
              return (
                <div
                  key={tile.title}
                  className="rounded-xl border border-slate-300/70 dark:border-slate-800/90 bg-white/65 dark:bg-[#0b1224]/65 backdrop-blur-md p-3.5 transition hover:border-cyan-500/45"
                >
                  <div className="flex items-center gap-2 mb-1.5">
                    <span
                      className={`inline-flex h-7 w-7 items-center justify-center rounded-lg border ${tile.accent}`}
                    >
                      <Icon className="h-3.5 w-3.5" />
                    </span>
                    <h2 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                      {tile.title}
                    </h2>
                  </div>
                  <p className="text-[11px] leading-relaxed text-slate-600 dark:text-slate-400">
                    {tile.detail}
                  </p>
                </div>
              );
            })}
          </div>
        </section>

        {/* Right Prism Login Portal Column (5 cols) */}
        <section className="lg:col-span-5 w-full max-w-md mx-auto lg:max-w-none">
          <div className="prism-border">
            <div className="prism-glass relative p-5 sm:p-7">
              {/* Subtle Optical Corner Brackets */}
              <span
                aria-hidden="true"
                className="pointer-events-none absolute top-3 left-3 h-3 w-3 border-t-2 border-l-2 border-cyan-500/50 rounded-tl"
              />
              <span
                aria-hidden="true"
                className="pointer-events-none absolute top-3 right-3 h-3 w-3 border-t-2 border-r-2 border-indigo-500/50 rounded-tr"
              />
              <span
                aria-hidden="true"
                className="pointer-events-none absolute bottom-3 left-3 h-3 w-3 border-b-2 border-l-2 border-indigo-500/50 rounded-bl"
              />
              <span
                aria-hidden="true"
                className="pointer-events-none absolute bottom-3 right-3 h-3 w-3 border-b-2 border-r-2 border-purple-500/50 rounded-br"
              />

              {/* Portal Header */}
              <div className="flex items-center justify-between gap-2 pb-4 mb-5 border-b border-slate-200/80 dark:border-slate-800/90">
                <div className="flex items-center gap-2 text-[11px] font-mono font-semibold tracking-wider text-slate-600 dark:text-cyan-300">
                  <ShieldCheck className="h-3.5 w-3.5 text-cyan-600 dark:text-cyan-400" />
                  ACCESS TERMINAL // PORTAL
                </div>
                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-mono font-medium text-emerald-700 dark:text-emerald-300">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                  PBKDF2 + JWT
                </span>
              </div>

              {isAuthenticated && !showSwitchForm ? (
                /* Active Session View */
                <div className="space-y-5 py-2">
                  <div className="rounded-2xl border border-cyan-500/30 bg-cyan-500/5 p-4 flex items-center gap-3.5">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-500 via-blue-600 to-purple-600 text-sm font-bold text-white shadow-md">
                      {getInitials(activeDisplayName)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-bold text-slate-900 dark:text-white truncate">
                          {activeDisplayName}
                        </span>
                        <span className="rounded-full bg-cyan-500/15 px-2 py-0.5 text-[10px] font-semibold text-cyan-700 dark:text-cyan-300">
                          {isGuest
                            ? 'Guest Pass'
                            : user?.is_demo
                              ? isOfflineDemo
                                ? 'Local Demo'
                                : 'Demo Account'
                              : activeRole}
                        </span>
                      </div>
                      <div className="text-xs text-slate-600 dark:text-slate-400 truncate mt-0.5">
                        {isGuest
                          ? 'Frictionless Local Guest Session'
                          : user?.email || profile.institution}
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                    Your workspace is active and ready. Jump straight back into the Quantum Lab
                    Control Center or switch credentials below.
                  </p>

                  <div className="space-y-2.5">
                    <button
                      type="button"
                      onClick={() => navigate(targetPath)}
                      className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-cyan-500/20 hover:from-cyan-400 hover:via-blue-500 hover:to-indigo-500 active:scale-[0.99] transition"
                    >
                      <span>Enter Quantum Lab</span>
                      <ArrowRight className="h-4 w-4" />
                    </button>

                    <div className="grid grid-cols-2 gap-2.5">
                      <button
                        type="button"
                        onClick={() => {
                          setShowSwitchForm(true);
                          setErrorMsg('');
                        }}
                        className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white/70 dark:bg-slate-900/70 px-3 py-2.5 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:border-cyan-400 hover:text-cyan-600 dark:hover:text-cyan-300 transition"
                      >
                        <UserPlus className="h-3.5 w-3.5" />
                        Switch Account
                      </button>

                      <button
                        type="button"
                        onClick={handleSignOut}
                        className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-rose-500/30 bg-rose-500/10 px-3 py-2.5 text-xs font-semibold text-rose-600 dark:text-rose-300 hover:bg-rose-500/20 transition"
                      >
                        <LogOut className="h-3.5 w-3.5" />
                        Sign Out
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                /* Login / Registration View */
                <div className="space-y-4">
                  {isAuthenticated && showSwitchForm && (
                    <button
                      type="button"
                      onClick={() => {
                        setShowSwitchForm(false);
                        setErrorMsg('');
                      }}
                      className="text-xs font-semibold text-cyan-600 dark:text-cyan-300 hover:underline inline-flex items-center gap-1"
                    >
                      ← Back to active session ({activeDisplayName})
                    </button>
                  )}

                  {/* Segmented Tab Bar */}
                  <div
                    role="tablist"
                    aria-label="Authentication mode"
                    className="grid grid-cols-2 rounded-xl border border-slate-200/90 dark:border-slate-800 bg-slate-100/90 dark:bg-[#060b18]/90 p-1"
                  >
                    <button
                      type="button"
                      role="tab"
                      aria-selected={activeTab === 'signin'}
                      onClick={() => handleTabChange('signin')}
                      className={`rounded-lg py-2 text-xs font-semibold transition ${
                        activeTab === 'signin'
                          ? 'bg-white dark:bg-slate-800 text-slate-950 dark:text-cyan-300 shadow-sm'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                      }`}
                    >
                      Sign In
                    </button>
                    <button
                      type="button"
                      role="tab"
                      aria-selected={activeTab === 'register'}
                      onClick={() => handleTabChange('register')}
                      className={`rounded-lg py-2 text-xs font-semibold transition ${
                        activeTab === 'register'
                          ? 'bg-white dark:bg-slate-800 text-slate-950 dark:text-cyan-300 shadow-sm'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                      }`}
                    >
                      Create Account
                    </button>
                  </div>

                  {/* Inline Error Banner */}
                  {errorMsg && (
                    <div
                      role="alert"
                      className="rounded-xl border border-rose-500/40 bg-rose-500/10 px-3.5 py-2.5 text-xs text-rose-700 dark:text-rose-200 flex items-start gap-2"
                    >
                      <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-rose-500" />
                      <span>{errorMsg}</span>
                    </div>
                  )}

                  {activeTab === 'signin' ? (
                    <form onSubmit={handleSignInSubmit} className="space-y-3.5">
                      <div>
                        <label
                          htmlFor="login-email"
                          className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                        >
                          Email Address
                        </label>
                        <input
                          id="login-email"
                          type="email"
                          autoComplete="email"
                          required
                          placeholder="researcher@quantumlab.io"
                          value={loginEmail}
                          onChange={(e) => setLoginEmail(e.target.value)}
                          className="w-full rounded-xl border border-slate-300/90 dark:border-slate-700/90 bg-white/90 dark:bg-[#060b18]/90 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/25 transition"
                        />
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label
                            htmlFor="login-password"
                            className="block text-xs font-semibold text-slate-700 dark:text-slate-300"
                          >
                            Password
                          </label>
                          <button
                            type="button"
                            onClick={() => setShowDemoHint((v) => !v)}
                            className="text-[11px] font-medium text-cyan-600 dark:text-cyan-400 hover:underline inline-flex items-center gap-1"
                          >
                            <KeyRound className="h-3 w-3" />
                            Demo credentials
                          </button>
                        </div>
                        <div className="relative">
                          <input
                            id="login-password"
                            type={showLoginPassword ? 'text' : 'password'}
                            autoComplete="current-password"
                            required
                            placeholder="Enter your password"
                            value={loginPassword}
                            onChange={(e) => setLoginPassword(e.target.value)}
                            className="w-full rounded-xl border border-slate-300/90 dark:border-slate-700/90 bg-white/90 dark:bg-[#060b18]/90 pl-3.5 pr-10 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/25 transition"
                          />
                          <button
                            type="button"
                            onClick={() => setShowLoginPassword((v) => !v)}
                            aria-label={showLoginPassword ? 'Hide password' : 'Show password'}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-lg p-1 text-slate-500 hover:text-cyan-500 transition"
                          >
                            {showLoginPassword ? (
                              <EyeOff className="h-4 w-4" />
                            ) : (
                              <Eye className="h-4 w-4" />
                            )}
                          </button>
                        </div>
                      </div>

                      {showDemoHint && (
                        <div className="rounded-xl border border-cyan-500/30 bg-cyan-500/10 p-3 flex items-center justify-between gap-2 text-xs">
                          <div className="font-mono text-[11px] text-slate-700 dark:text-cyan-200">
                            <div>Email: ada@quantumlab.io</div>
                            <div>Pass: Quantum2026!</div>
                          </div>
                          <button
                            type="button"
                            onClick={handleAutofillDemo}
                            className="shrink-0 rounded-lg bg-cyan-500/20 border border-cyan-500/40 px-2.5 py-1 text-[11px] font-semibold text-cyan-700 dark:text-cyan-200 hover:bg-cyan-500/30 transition"
                          >
                            Autofill
                          </button>
                        </div>
                      )}

                      <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400 cursor-pointer select-none">
                        <input
                          type="checkbox"
                          checked={rememberMe}
                          onChange={(e) => setRememberMe(e.target.checked)}
                          className="h-3.5 w-3.5 rounded border-slate-400 text-cyan-500 focus:ring-cyan-500"
                        />
                        Keep me signed in on this browser
                      </label>

                      <button
                        type="submit"
                        disabled={submitting}
                        className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-cyan-500/20 hover:from-cyan-400 hover:via-blue-500 hover:to-indigo-500 disabled:opacity-60 disabled:cursor-not-allowed active:scale-[0.99] transition"
                      >
                        <span>{submitting ? 'Authenticating...' : 'Sign In to Quantum Lab'}</span>
                        <ArrowRight className="h-4 w-4" />
                      </button>
                    </form>
                  ) : (
                    <form onSubmit={handleRegisterSubmit} className="space-y-3">
                      <div>
                        <label
                          htmlFor="reg-name"
                          className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                        >
                          Full Name
                        </label>
                        <input
                          id="reg-name"
                          type="text"
                          autoComplete="name"
                          required
                          placeholder="Dr. Alan Turing"
                          value={regName}
                          onChange={(e) => setRegName(e.target.value)}
                          className="w-full rounded-xl border border-slate-300/90 dark:border-slate-700/90 bg-white/90 dark:bg-[#060b18]/90 px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/25 transition"
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="reg-email"
                          className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                        >
                          Email Address
                        </label>
                        <input
                          id="reg-email"
                          type="email"
                          autoComplete="email"
                          required
                          placeholder="you@university.edu"
                          value={regEmail}
                          onChange={(e) => setRegEmail(e.target.value)}
                          className="w-full rounded-xl border border-slate-300/90 dark:border-slate-700/90 bg-white/90 dark:bg-[#060b18]/90 px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/25 transition"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        <div>
                          <label
                            htmlFor="reg-role"
                            className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                          >
                            Role
                          </label>
                          <select
                            id="reg-role"
                            value={regRole}
                            onChange={(e) => setRegRole(e.target.value)}
                            className="w-full rounded-xl border border-slate-300/90 dark:border-slate-700/90 bg-white/90 dark:bg-[#060b18]/90 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 focus:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/25 transition"
                          >
                            <option value="Student">Student</option>
                            <option value="Researcher">Researcher</option>
                            <option value="Educator">Educator</option>
                            <option value="Beginner">Beginner</option>
                          </select>
                        </div>

                        <div>
                          <label
                            htmlFor="reg-inst"
                            className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                          >
                            Institution <span className="font-normal opacity-70">(optional)</span>
                          </label>
                          <input
                            id="reg-inst"
                            type="text"
                            placeholder="Quantum Institute"
                            value={regInstitution}
                            onChange={(e) => setRegInstitution(e.target.value)}
                            className="w-full rounded-xl border border-slate-300/90 dark:border-slate-700/90 bg-white/90 dark:bg-[#060b18]/90 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/25 transition"
                          />
                        </div>
                      </div>

                      <div>
                        <label
                          htmlFor="reg-password"
                          className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                        >
                          Password
                        </label>
                        <div className="relative">
                          <input
                            id="reg-password"
                            type={showRegPassword ? 'text' : 'password'}
                            autoComplete="new-password"
                            required
                            minLength={6}
                            placeholder="At least 6 characters"
                            value={regPassword}
                            onChange={(e) => setRegPassword(e.target.value)}
                            className="w-full rounded-xl border border-slate-300/90 dark:border-slate-700/90 bg-white/90 dark:bg-[#060b18]/90 pl-3.5 pr-10 py-2 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/25 transition"
                          />
                          <button
                            type="button"
                            onClick={() => setShowRegPassword((v) => !v)}
                            aria-label={showRegPassword ? 'Hide password' : 'Show password'}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-lg p-1 text-slate-500 hover:text-cyan-500 transition"
                          >
                            {showRegPassword ? (
                              <EyeOff className="h-4 w-4" />
                            ) : (
                              <Eye className="h-4 w-4" />
                            )}
                          </button>
                        </div>

                        {/* 4-Segment Strength Bar */}
                        {regPassword.length > 0 && (
                          <div className="mt-1.5 flex items-center gap-2">
                            <div className="grid grid-cols-4 gap-1 flex-1">
                              {[1, 2, 3, 4].map((seg) => (
                                <span
                                  key={seg}
                                  className={`h-1 rounded-full transition-colors ${
                                    passwordStrength.score >= seg
                                      ? passwordStrength.color
                                      : 'bg-slate-200 dark:bg-slate-800'
                                  }`}
                                />
                              ))}
                            </div>
                            <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400">
                              {passwordStrength.label}
                            </span>
                          </div>
                        )}
                      </div>

                      <div>
                        <label
                          htmlFor="reg-confirm"
                          className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                        >
                          Confirm Password
                        </label>
                        <input
                          id="reg-confirm"
                          type={showRegPassword ? 'text' : 'password'}
                          autoComplete="new-password"
                          required
                          placeholder="Re-enter password"
                          value={regConfirm}
                          onChange={(e) => setRegConfirm(e.target.value)}
                          className={`w-full rounded-xl border bg-white/90 dark:bg-[#060b18]/90 px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 transition ${
                            passwordsMismatch
                              ? 'border-rose-500 focus:border-rose-500 focus:ring-rose-500/25'
                              : 'border-slate-300/90 dark:border-slate-700/90 focus:border-cyan-500 focus:ring-cyan-500/25'
                          }`}
                        />
                        {passwordsMismatch && (
                          <p className="mt-1 text-[11px] text-rose-600 dark:text-rose-400">
                            Passwords do not match.
                          </p>
                        )}
                      </div>

                      <button
                        type="submit"
                        disabled={submitting || passwordsMismatch}
                        className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-cyan-500/20 hover:from-cyan-400 hover:via-blue-500 hover:to-purple-500 disabled:opacity-60 disabled:cursor-not-allowed active:scale-[0.99] transition"
                      >
                        <CheckCircle2 className="h-4 w-4" />
                        <span>{submitting ? 'Creating Account...' : 'Create Researcher Account'}</span>
                      </button>
                    </form>
                  )}

                  {/* Quick Access Divider */}
                  <div className="relative py-1">
                    <div className="absolute inset-0 flex items-center" aria-hidden="true">
                      <div className="w-full border-t border-slate-200 dark:border-slate-800" />
                    </div>
                    <div className="relative flex justify-center">
                      <span className="bg-white/95 dark:bg-[#0b1122] px-2.5 text-[10px] font-mono font-semibold tracking-widest text-slate-500 dark:text-slate-400 rounded">
                        OR INSTANT ACCESS
                      </span>
                    </div>
                  </div>

                  {/* Quick-Login Option Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <button
                      type="button"
                      onClick={handleDemoAccess}
                      disabled={demoLoading}
                      className="group text-left rounded-xl border border-cyan-500/30 bg-cyan-500/10 hover:bg-cyan-500/15 hover:border-cyan-400/60 p-3 transition disabled:opacity-60"
                    >
                      <div className="flex items-center justify-between gap-1.5">
                        <span className="inline-flex items-center gap-1.5 text-xs font-bold text-cyan-700 dark:text-cyan-300">
                          <Sparkles className="h-3.5 w-3.5" />
                          Demo Researcher
                        </span>
                        <ArrowRight className="h-3.5 w-3.5 text-cyan-600 dark:text-cyan-300 transition-transform group-hover:translate-x-0.5" />
                      </div>
                      <p className="mt-1 text-[11px] text-slate-600 dark:text-slate-400 truncate">
                        {demoLoading ? 'Connecting...' : '1-click as Dr. Ada Vance'}
                      </p>
                    </button>

                    <button
                      type="button"
                      onClick={handleGuestPass}
                      className="group text-left rounded-xl border border-slate-300/90 dark:border-slate-700/90 bg-slate-100/80 dark:bg-slate-900/75 hover:border-indigo-400/60 hover:bg-indigo-500/10 p-3 transition"
                    >
                      <div className="flex items-center justify-between gap-1.5">
                        <span className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-200">
                          <UserCheck className="h-3.5 w-3.5 text-indigo-500 dark:text-indigo-400" />
                          Guest Lab Pass
                        </span>
                        <ArrowRight className="h-3.5 w-3.5 text-slate-500 dark:text-slate-400 transition-transform group-hover:translate-x-0.5" />
                      </div>
                      <p className="mt-1 text-[11px] text-slate-600 dark:text-slate-400 truncate">
                        Enter without an account
                      </p>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </section>
      </main>

      {/* Minimal Footer Bar */}
      <footer className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 border-t border-slate-300/50 dark:border-slate-800/70 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-slate-500 dark:text-slate-400">
        <div className="font-medium">
          QUANTUM LAB · Explore. Experiment. Understand. Innovate.
        </div>
        <div className="font-mono">
          8 Qubits · 10K Shots · SQLite Persistence
        </div>
      </footer>
    </div>
  );
}
