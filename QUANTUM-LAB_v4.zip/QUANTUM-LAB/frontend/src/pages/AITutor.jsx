import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, CheckCircle2, Cpu, KeyRound, Play, Workflow } from 'lucide-react';
import toast from 'react-hot-toast';
import { useQuantum } from '../context/QuantumContext';
import { useTheme } from '../context/ThemeContext';
import { extractApiError, saveAIConfig } from '../services/api';
import TutorChat from '../components/tutor/TutorChat';

const PROVIDER_DEFAULT_MODELS = {
  gemini: 'gemini-2.0-flash',
  openai: 'gpt-4o-mini',
  anthropic: 'claude-3-5-sonnet-latest',
};

export default function AITutor() {
  const { profile } = useTheme();
  const {
    serializedCircuit,
    simulationResult,
    isSimulating,
    executeSimulation,
    backendHealth,
    refreshHealth,
  } = useQuantum();

  const [showKeyForm, setShowKeyForm] = useState(false);
  const [provider, setProvider] = useState('gemini');
  const [apiKey, setApiKey] = useState('');
  const [model, setModel] = useState(PROVIDER_DEFAULT_MODELS.gemini);
  const [savingKey, setSavingKey] = useState(false);

  const handleProviderChange = (nextProvider) => {
    setProvider(nextProvider);
    setModel(PROVIDER_DEFAULT_MODELS[nextProvider] || '');
  };

  const handleSaveKey = async (e) => {
    e.preventDefault();
    if (!apiKey.trim() || savingKey) return;
    setSavingKey(true);
    try {
      const res = await saveAIConfig({
        provider,
        api_key: apiKey.trim(),
        model: model.trim() || null,
      });
      await refreshHealth();
      setApiKey('');
      setShowKeyForm(false);
      toast.success(
        res.ai_configured
          ? `Live LLM active (${res.ai_provider} · ${res.ai_model})`
          : 'API key cleared — using offline Qiskit tutor mode.'
      );
    } catch (err) {
      toast.error(extractApiError(err, 'Failed to save AI API key.'));
    } finally {
      setSavingKey(false);
    }
  };

  const topProbs = simulationResult?.probabilities
    ? Object.entries(simulationResult.probabilities)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 6)
    : [];

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[var(--lab-text)]">
            AI Quantum Tutor — Q-ASSIST
          </h1>
          <p className="text-xs sm:text-sm text-[var(--lab-muted)]">
            Context-aware quantum explanations grounded strictly in your active circuit and verified Qiskit simulator outputs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => executeSimulation()}
            disabled={isSimulating}
            className="sci-btn-primary text-xs"
          >
            <Play className="h-3.5 w-3.5" />
            {isSimulating ? 'Simulating...' : 'Run Active Circuit'}
          </button>
          <Link to="/circuit-builder" className="sci-btn-secondary text-xs">
            <Workflow className="h-3.5 w-3.5 text-cyan-400" />
            Edit Circuit
          </Link>
        </div>
      </div>

      {backendHealth && !backendHealth.ai_configured && (
        <div className="rounded-xl border border-amber-500/35 bg-amber-500/10 p-3.5 text-xs text-amber-200 space-y-3">
          <div className="flex flex-wrap items-start justify-between gap-2.5">
            <div className="flex items-start gap-2.5 flex-1 min-w-[240px]">
              <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong>Non-AI Educational Reference Mode Active:</strong> No{' '}
                <code className="font-mono">AI_API_KEY</code> is configured in{' '}
                <code className="font-mono">backend/.env</code>. Q-ASSIST uses Qiskit simulator diagnostics and curated physics references.
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowKeyForm((v) => !v)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-amber-400/40 bg-amber-500/15 px-3 py-1.5 text-[11px] font-semibold text-amber-200 hover:bg-amber-500/25 transition shrink-0"
            >
              <KeyRound className="h-3.5 w-3.5" />
              {showKeyForm ? 'Hide' : 'Configure AI API Key'}
            </button>
          </div>
          {showKeyForm && (
            <form onSubmit={handleSaveKey} className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-2 border-t border-amber-500/20">
              <select
                aria-label="AI Provider"
                value={provider}
                onChange={(e) => handleProviderChange(e.target.value)}
                className="sci-input sm:col-span-3 text-xs"
              >
                <option value="gemini">Google Gemini</option>
                <option value="openai">OpenAI</option>
                <option value="anthropic">Anthropic Claude</option>
              </select>
              <input
                type="password"
                aria-label="AI API Key"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="Paste your AI_API_KEY..."
                className="sci-input sm:col-span-4 text-xs"
                required
              />
              <input
                type="text"
                aria-label="AI Model"
                value={model}
                onChange={(e) => setModel(e.target.value)}
                placeholder="Model (optional)"
                className="sci-input sm:col-span-3 text-xs"
              />
              <button
                type="submit"
                disabled={savingKey || !apiKey.trim()}
                className="sci-btn-primary sm:col-span-2 text-xs justify-center"
              >
                {savingKey ? 'Saving...' : 'Save Key'}
              </button>
            </form>
          )}
        </div>
      )}

      {backendHealth && backendHealth.ai_configured && (
        <div className="rounded-xl border border-emerald-500/35 bg-emerald-500/10 p-3 text-xs text-emerald-200 space-y-2.5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
              <span>
                <strong>Live LLM Connected:</strong>{' '}
                <code className="font-mono">{backendHealth.ai_provider}</code> ·{' '}
                <code className="font-mono">{backendHealth.ai_model}</code>
              </span>
            </div>
            <button
              type="button"
              onClick={() => setShowKeyForm((v) => !v)}
              className="inline-flex items-center gap-1 rounded-lg border border-emerald-400/30 bg-emerald-500/10 px-2.5 py-1 text-[11px] font-semibold text-emerald-200 hover:bg-emerald-500/20 transition"
            >
              <KeyRound className="h-3 w-3" />
              {showKeyForm ? 'Hide' : 'Update AI Key'}
            </button>
          </div>
          {showKeyForm && (
            <form onSubmit={handleSaveKey} className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-2 border-t border-emerald-500/20">
              <select
                aria-label="AI Provider"
                value={provider}
                onChange={(e) => handleProviderChange(e.target.value)}
                className="sci-input sm:col-span-3 text-xs"
              >
                <option value="gemini">Google Gemini</option>
                <option value="openai">OpenAI</option>
                <option value="anthropic">Anthropic Claude</option>
              </select>
              <input
                type="password"
                aria-label="AI API Key"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="Paste new AI_API_KEY..."
                className="sci-input sm:col-span-4 text-xs"
                required
              />
              <input
                type="text"
                aria-label="AI Model"
                value={model}
                onChange={(e) => setModel(e.target.value)}
                placeholder="Model (optional)"
                className="sci-input sm:col-span-3 text-xs"
              />
              <button
                type="submit"
                disabled={savingKey || !apiKey.trim()}
                className="sci-btn-primary sm:col-span-2 text-xs justify-center"
              >
                {savingKey ? 'Saving...' : 'Save Key'}
              </button>
            </form>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Main Q-ASSIST Chat */}
        <div className="lg:col-span-8">
          <TutorChat
            circuit={serializedCircuit}
            simulationResult={simulationResult}
            aiConfigured={Boolean(backendHealth?.ai_configured)}
            initialLevel={profile.defaultLevel || 'beginner'}
          />
        </div>

        {/* Context Inspector Sidebar */}
        <div className="lg:col-span-4 space-y-4">
          <div className="sci-card p-4 space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-cyan-400">
              <Cpu className="h-4 w-4" />
              Live Context Shared With Q-ASSIST
            </div>

            <div className="rounded-lg border border-[var(--lab-border)] bg-[var(--lab-elevated)] p-3 text-xs space-y-1.5 font-mono">
              <div className="flex justify-between">
                <span className="text-[var(--lab-muted)]">Qubits</span>
                <span className="text-[var(--lab-text)] font-bold">{serializedCircuit.num_qubits}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--lab-muted)]">Init Basis</span>
                <span className="text-cyan-400">|{serializedCircuit.initial_state}⟩</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--lab-muted)]">Gates</span>
                <span className="text-[var(--lab-text)]">{serializedCircuit.gates.length}</span>
              </div>
            </div>

            {serializedCircuit.gates.length > 0 && (
              <div className="space-y-1">
                <div className="text-[11px] font-semibold text-[var(--lab-muted)]">
                  Gate Sequence
                </div>
                <div className="flex flex-wrap gap-1">
                  {serializedCircuit.gates.map((g, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded bg-[var(--lab-elevated)] border border-[var(--lab-border)] text-[11px] font-mono text-cyan-300"
                    >
                      {g.gate_name}({[...(g.control_qubits || []), ...(g.target_qubits || [])].join(',')})
                    </span>
                  ))}
                </div>
              </div>
            )}

            <div className="pt-2 border-t border-[var(--lab-border)]">
              <div className="text-[11px] font-semibold text-[var(--lab-muted)] mb-1.5">
                Verified Simulator Output
              </div>
              {!simulationResult ? (
                <p className="text-xs text-[var(--lab-muted)]">
                  No simulation executed yet. Click <strong>Run Active Circuit</strong> above so Q-ASSIST can interpret actual probabilities.
                </p>
              ) : (
                <div className="space-y-1.5 font-mono text-xs">
                  <div className="text-[11px] text-emerald-400">
                    Mode: {simulationResult.simulation_mode.toUpperCase()} (Qiskit Software Simulator)
                  </div>
                  {topProbs.map(([state, p]) => (
                    <div
                      key={state}
                      className="flex items-center justify-between rounded bg-[var(--lab-elevated)] px-2.5 py-1"
                    >
                      <span className="text-cyan-400">|{state}⟩</span>
                      <span className="text-[var(--lab-text)]">
                        {(p * 100).toFixed(2)}% ({simulationResult.measurements?.[state] ?? 0} shots)
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="sci-card p-4 text-xs text-[var(--lab-muted)] space-y-1.5">
            <div className="font-semibold text-[var(--lab-text)]">Scientific Integrity Policy</div>
            <p>
              Q-ASSIST never fabricates measurement outcomes and always clearly distinguishes software simulator results from physical quantum hardware.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
