import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import {
  fetchCurrentUser,
  loginDemoUser,
  loginUser,
  logoutUser,
  registerUser,
  setAuthToken,
  updateAuthProfile,
} from '../services/api';
import { useTheme } from './ThemeContext';

const AuthContext = createContext(null);

const STORAGE_AUTH_KEY = 'quantum_lab_auth_session';

const OFFLINE_DEMO_USER = {
  id: 0,
  name: 'Dr. Ada Vance',
  email: 'ada@quantumlab.io',
  role: 'Researcher',
  institution: 'Quantum Observatory Lab',
  is_demo: true,
};

function readStoredSession() {
  try {
    const localRaw = localStorage.getItem(STORAGE_AUTH_KEY);
    if (localRaw) {
      return { ...JSON.parse(localRaw), remember: true };
    }
    const sessionRaw = sessionStorage.getItem(STORAGE_AUTH_KEY);
    if (sessionRaw) {
      return { ...JSON.parse(sessionRaw), remember: false };
    }
  } catch {
    // Ignore storage read errors
  }
  return null;
}

function writeStoredSession(session, remember) {
  try {
    localStorage.removeItem(STORAGE_AUTH_KEY);
    sessionStorage.removeItem(STORAGE_AUTH_KEY);
    if (!session) return;
    const serialized = JSON.stringify({ ...session, remember: Boolean(remember) });
    if (remember) {
      localStorage.setItem(STORAGE_AUTH_KEY, serialized);
    } else {
      sessionStorage.setItem(STORAGE_AUTH_KEY, serialized);
    }
  } catch {
    // Ignore storage write errors
  }
}

export function AuthProvider({ children }) {
  const { updateProfile } = useTheme();
  const updateProfileRef = useRef(updateProfile);
  updateProfileRef.current = updateProfile;

  const [sessionState, setSessionState] = useState({
    user: null,
    token: null,
    authMode: null,
    isOfflineDemo: false,
    remember: true,
  });
  const [isReady, setIsReady] = useState(false);

  const syncUserToThemeProfile = useCallback((userData) => {
    if (!userData) return;
    updateProfileRef.current({
      name: userData.name || 'Researcher',
      role: userData.role || 'Student',
      institution: userData.institution || 'Quantum Lab Workspace',
    });
  }, []);

  const applyAuthenticatedSession = useCallback(
    (userData, accessToken, { remember = true, isOfflineDemo = false } = {}) => {
      setAuthToken(accessToken || null);
      const next = {
        user: userData,
        token: accessToken || null,
        authMode: 'authenticated',
        isOfflineDemo,
        remember,
      };
      setSessionState(next);
      writeStoredSession(
        {
          user: userData,
          token: accessToken || null,
          authMode: 'authenticated',
          isOfflineDemo,
        },
        remember
      );
      syncUserToThemeProfile(userData);
    },
    [syncUserToThemeProfile]
  );

  useEffect(() => {
    let active = true;

    async function bootstrapAuth() {
      const stored = readStoredSession();
      if (!stored || !stored.authMode) {
        if (active) setIsReady(true);
        return;
      }

      if (stored.authMode === 'guest') {
        setAuthToken(null);
        if (active) {
          setSessionState({
            user: null,
            token: null,
            authMode: 'guest',
            isOfflineDemo: false,
            remember: false,
          });
          setIsReady(true);
        }
        return;
      }

      // Restore authenticated or offline demo session immediately
      setAuthToken(stored.token || null);
      if (active) {
        setSessionState({
          user: stored.user || null,
          token: stored.token || null,
          authMode: 'authenticated',
          isOfflineDemo: Boolean(stored.isOfflineDemo),
          remember: stored.remember !== false,
        });
        if (stored.user) {
          syncUserToThemeProfile(stored.user);
        }
      }

      if (stored.token && !stored.isOfflineDemo) {
        try {
          const freshUser = await fetchCurrentUser();
          if (!active) return;
          applyAuthenticatedSession(freshUser, stored.token, {
            remember: stored.remember !== false,
            isOfflineDemo: false,
          });
        } catch (err) {
          if (!active) return;
          if (err?.response?.status === 401) {
            setAuthToken(null);
            writeStoredSession(null, false);
            setSessionState({
              user: null,
              token: null,
              authMode: null,
              isOfflineDemo: false,
              remember: true,
            });
          }
        }
      }

      if (active) setIsReady(true);
    }

    bootstrapAuth();
    return () => {
      active = false;
    };
  }, [applyAuthenticatedSession, syncUserToThemeProfile]);

  const signIn = useCallback(
    async ({ email, password, remember = true }) => {
      const data = await loginUser({ email, password });
      applyAuthenticatedSession(data.user, data.access_token, {
        remember,
        isOfflineDemo: false,
      });
      return data.user;
    },
    [applyAuthenticatedSession]
  );

  const signUp = useCallback(
    async ({ name, email, password, role = 'Student', institution = 'Quantum Lab Workspace', remember = true }) => {
      const data = await registerUser({ name, email, password, role, institution });
      applyAuthenticatedSession(data.user, data.access_token, {
        remember,
        isOfflineDemo: false,
      });
      return data.user;
    },
    [applyAuthenticatedSession]
  );

  const signInDemo = useCallback(
    async ({ remember = true } = {}) => {
      try {
        const data = await loginDemoUser();
        applyAuthenticatedSession(data.user, data.access_token, {
          remember,
          isOfflineDemo: false,
        });
        return { user: data.user, offline: false };
      } catch (err) {
        // Graceful fallback when backend is not currently running
        if (!err?.response) {
          applyAuthenticatedSession(OFFLINE_DEMO_USER, null, {
            remember,
            isOfflineDemo: true,
          });
          return { user: OFFLINE_DEMO_USER, offline: true };
        }
        throw err;
      }
    },
    [applyAuthenticatedSession]
  );

  const enterAsGuest = useCallback(() => {
    setAuthToken(null);
    const next = {
      user: null,
      token: null,
      authMode: 'guest',
      isOfflineDemo: false,
      remember: false,
    };
    setSessionState(next);
    writeStoredSession(
      {
        user: null,
        token: null,
        authMode: 'guest',
        isOfflineDemo: false,
      },
      false
    );
  }, []);

  const updateAccountProfile = useCallback(
    async (updates) => {
      const { name, role, institution } = updates || {};
      if (sessionState.token && !sessionState.isOfflineDemo) {
        const updatedUser = await updateAuthProfile({ name, role, institution });
        applyAuthenticatedSession(updatedUser, sessionState.token, {
          remember: sessionState.remember,
          isOfflineDemo: false,
        });
        return updatedUser;
      }

      if (sessionState.authMode === 'authenticated' && sessionState.user) {
        const merged = {
          ...sessionState.user,
          ...(name !== undefined ? { name } : {}),
          ...(role !== undefined ? { role } : {}),
          ...(institution !== undefined ? { institution } : {}),
        };
        applyAuthenticatedSession(merged, sessionState.token, {
          remember: sessionState.remember,
          isOfflineDemo: sessionState.isOfflineDemo,
        });
        return merged;
      }

      updateProfileRef.current(updates);
      return null;
    },
    [
      applyAuthenticatedSession,
      sessionState.authMode,
      sessionState.isOfflineDemo,
      sessionState.remember,
      sessionState.token,
      sessionState.user,
    ]
  );

  const signOut = useCallback(() => {
    logoutUser().catch(() => {});
    setAuthToken(null);
    writeStoredSession(null, false);
    setSessionState({
      user: null,
      token: null,
      authMode: null,
      isOfflineDemo: false,
      remember: true,
    });
  }, []);

  const isAuthenticated =
    sessionState.authMode === 'authenticated' || sessionState.authMode === 'guest';
  const isGuest = sessionState.authMode === 'guest';

  return (
    <AuthContext.Provider
      value={{
        user: sessionState.user,
        token: sessionState.token,
        authMode: sessionState.authMode,
        isOfflineDemo: sessionState.isOfflineDemo,
        isReady,
        isAuthenticated,
        isGuest,
        signIn,
        signUp,
        signInDemo,
        enterAsGuest,
        updateAccountProfile,
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used inside AuthProvider');
  }
  return ctx;
}
