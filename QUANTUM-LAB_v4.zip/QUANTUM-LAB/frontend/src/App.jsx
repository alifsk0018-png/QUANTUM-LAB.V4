import React from 'react';
import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { QuantumProvider } from './context/QuantumContext';
import ErrorBoundary from './components/ui/ErrorBoundary';
import MainLayout from './components/layout/MainLayout';
import OpeningPage from './pages/OpeningPage';
import Dashboard from './pages/Dashboard';
import QuantumLab from './pages/QuantumLab';
import CircuitBuilder from './pages/CircuitBuilder';
import QuantumExperiments from './pages/QuantumExperiments';
import QuantumVisualizer from './pages/QuantumVisualizer';
import AITutor from './pages/AITutor';
import LearningAcademy from './pages/LearningAcademy';
import ResearchWorkspace from './pages/ResearchWorkspace';
import SavedExperiments from './pages/SavedExperiments';
import Settings from './pages/Settings';

function ProtectedAppShell() {
  const { isReady, isAuthenticated } = useAuth();
  const location = useLocation();

  if (!isReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[var(--lab-bg)] text-[var(--lab-muted)] text-sm font-mono">
        Initializing QUANTUM LAB Observatory...
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/" state={{ from: location }} replace />;
  }

  return <MainLayout />;
}

export default function App() {
  return (
    <ErrorBoundary fallbackTitle="QUANTUM LAB Application Error">
      <ThemeProvider>
        <AuthProvider>
          <QuantumProvider>
            <BrowserRouter>
              <Routes>
                <Route path="/" element={<OpeningPage />} />
                <Route path="/login" element={<Navigate to="/" replace />} />

                <Route element={<ProtectedAppShell />}>
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/laboratory" element={<QuantumLab />} />
                  <Route path="/circuit-builder" element={<CircuitBuilder />} />
                  <Route path="/experiments" element={<QuantumExperiments />} />
                  <Route path="/visualizer" element={<QuantumVisualizer />} />
                  <Route path="/tutor" element={<AITutor />} />
                  <Route path="/academy" element={<LearningAcademy />} />
                  <Route path="/research" element={<ResearchWorkspace />} />
                  <Route path="/saved" element={<SavedExperiments />} />
                  <Route path="/settings" element={<Settings />} />
                </Route>

                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </BrowserRouter>

            <Toaster
              position="bottom-right"
              toastOptions={{
                style: {
                  background: '#0f172a',
                  color: '#e2e8f0',
                  border: '1px solid rgba(56, 189, 248, 0.3)',
                  fontSize: '13px',
                },
              }}
            />
          </QuantumProvider>
        </AuthProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
